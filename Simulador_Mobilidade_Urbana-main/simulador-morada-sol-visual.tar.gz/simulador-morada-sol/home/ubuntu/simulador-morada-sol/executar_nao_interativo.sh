
#!/bin/bash

echo "====================================================="
echo "  SIMULADOR DE MOBILIDADE URBANA - MORADA DO SOL"
echo "====================================================="
echo "  MODO NÃO INTERATIVO"
echo "====================================================="
echo

# Verifica se o JDK está instalado
if ! command -v javac &> /dev/null; then
    echo "Erro: JDK não encontrado. Por favor, instale o JDK."
    exit 1
fi

echo "Compilando o simulador..."
# Cria o diretório de saída para os arquivos compilados
mkdir -p bin

# Compila todos os arquivos Java
javac -d bin -cp bin $(find src -name "*.java")

# Verifica se a compilação foi bem-sucedida
if [ $? -ne 0 ]; then
    echo "Erro durante a compilação. Verifique os erros acima."
    exit 1
fi

echo "Compilação concluída com sucesso!"
echo

echo "Executando o simulador em segundo plano..."
echo "A simulação será executada por 60 segundos com configurações padrão."
echo "Os resultados serão salvos no arquivo relatorio_morada_sol_otimizacao_do_tempo_de_espera.txt"
echo

# Executa a classe principal em segundo plano
# Redireciona a entrada para /dev/null para evitar esperar por entrada do usuário
# Limita a duração da simulação para 60 segundos
# Executa o simulador com uma duração curta (60 segundos)
# Redireciona a entrada para /dev/null para evitar esperar por entrada do usuário
# Configura a duração da simulação para 60 segundos usando uma propriedade do sistema
java -cp bin -Dsimulacao.duracao=60 com.simulador.principal.SimuladorMain < /dev/null > simulacao.log 2>&1

echo
echo "Simulação finalizada."
echo "Verifique o arquivo relatorio_morada_sol_otimizacao_do_tempo_de_espera.txt para os resultados."
echo "====================================================="
