
# Simulador de Mobilidade Urbana - Bairro Morada do Sol (Teresina)

Este simulador representa a mobilidade urbana no bairro Morada do Sol em Teresina, com foco na otimização do tempo de espera nos semáforos (Modelo 2).

## Características

- **Mapa do Bairro Morada do Sol**: Representação das principais ruas, interseções e pontos de referência do bairro.
- **Modelo de Controle de Semáforos**: Implementa apenas o Modelo 2 (otimização do tempo de espera).
- **Estados Aleatórios de Semáforos**: Os semáforos iniciam com estados aleatórios (verde, amarelo e vermelho).
- **Visualização no Terminal**: Interface clara e informativa com cores para melhor visualização.
- **Estatísticas em Tempo Real**: Acompanhamento de métricas como tempo médio de espera e congestionamento.

## Requisitos

- Java Development Kit (JDK) 8 ou superior
- Terminal com suporte a cores ANSI

## Compilação

Para compilar o simulador, execute os seguintes comandos no terminal:

```bash
# Navegue até o diretório do projeto
cd ~/simulador-morada-sol

# Crie o diretório de saída para os arquivos compilados
mkdir -p bin

# Compile todos os arquivos Java
javac -d bin -cp bin $(find src -name "*.java")
```

## Execução

Para executar o simulador, use o seguinte comando:

```bash
# Execute a classe principal
java -cp bin com.simulador.principal.SimuladorMain
```

## Configuração

Ao iniciar o simulador, você poderá configurar:

1. **Duração da Simulação**: Tempo total da simulação em segundos (padrão: 300s).
2. **Velocidade da Simulação**: Velocidade de atualização (lenta, normal ou rápida).
3. **Número de Veículos**: Quantidade inicial e máxima de veículos na simulação.
4. **Taxa de Geração**: Probabilidade de novos veículos serem adicionados a cada ciclo.

## Legenda da Visualização

- **Ruas**: Representadas por caracteres `-` (horizontais) e `|` (verticais).
- **Interseções**: Representadas pelo caractere `+`.
- **Semáforos**:
  - 🟢 Verde: Os veículos podem passar.
  - 🟡 Amarelo: Os veículos devem parar se possível.
  - 🔴 Vermelho: Os veículos devem parar.
- **Veículos**:
  - 🔵 Azul: Veículo recém-adicionado.
  - 🟢 Verde: Veículo em movimento.
  - 🔴 Vermelho: Veículo parado em um semáforo.
- **Pontos de Referência**: Representados pelo caractere `P`.

## Relatórios

Ao final da simulação, um relatório detalhado é gerado com estatísticas como:
- Tempo médio de espera nos semáforos
- Fluxo de veículos por rua
- Níveis de congestionamento
- Eficiência do modelo de controle de semáforos

O relatório é salvo no arquivo `relatorio_morada_sol_otimizacao_do_tempo_de_espera.txt`.

## Script de Execução Rápida

Para facilitar a compilação e execução, você pode usar o script `executar.sh`:

```bash
#!/bin/bash
# Compilar
mkdir -p bin
javac -d bin -cp bin $(find src -name "*.java")

# Executar
java -cp bin com.simulador.principal.SimuladorMain
```

Para usar o script:
```bash
chmod +x executar.sh
./executar.sh
```
