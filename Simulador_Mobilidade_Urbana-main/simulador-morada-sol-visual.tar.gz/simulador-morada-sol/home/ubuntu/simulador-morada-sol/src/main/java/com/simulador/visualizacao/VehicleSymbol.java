
package com.simulador.visualizacao;

/**
 * Classe que representa um símbolo de veículo no mapa.
 * Cada veículo é representado por um caractere com uma cor específica.
 */
public class VehicleSymbol {
    private char symbol;
    private String color;
    
    /**
     * Construtor do símbolo de veículo
     * 
     * @param symbol Caractere que representa o veículo
     * @param color Cor do veículo (código ANSI)
     */
    public VehicleSymbol(char symbol, String color) {
        this.symbol = symbol;
        this.color = color;
    }
    
    /**
     * Renderiza o símbolo do veículo com a cor apropriada
     * 
     * @return String formatada com o símbolo colorido
     */
    public String render() {
        return color + symbol + TerminalRenderer.ANSI_RESET;
    }
    
    /**
     * Obtém o símbolo do veículo
     * 
     * @return Caractere que representa o veículo
     */
    public char getSymbol() {
        return symbol;
    }
    
    /**
     * Define o símbolo do veículo
     * 
     * @param symbol Novo caractere para representar o veículo
     */
    public void setSymbol(char symbol) {
        this.symbol = symbol;
    }
    
    /**
     * Obtém a cor do veículo
     * 
     * @return Código ANSI da cor
     */
    public String getColor() {
        return color;
    }
    
    /**
     * Define a cor do veículo
     * 
     * @param color Novo código ANSI para a cor
     */
    public void setColor(String color) {
        this.color = color;
    }
}
