
package com.simulador.visualizacao;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Classe que representa um painel de estatísticas.
 * Exibe informações como número de veículos, tempo de simulação, etc.
 */
public class StatsPanel {
    private int width;
    private int height;
    private Map<String, String> stats;
    
    /**
     * Construtor do painel de estatísticas
     * 
     * @param width Largura do painel
     * @param height Altura do painel
     */
    public StatsPanel(int width, int height) {
        this.width = width;
        this.height = height;
        this.stats = new LinkedHashMap<>();
    }
    
    /**
     * Atualiza uma estatística no painel
     * 
     * @param key Chave da estatística
     * @param value Valor da estatística
     */
    public void updateStat(String key, String value) {
        stats.put(key, value);
    }
    
    /**
     * Renderiza o painel de estatísticas
     * 
     * @return String contendo a representação do painel
     */
    public String render() {
        StringBuilder sb = new StringBuilder();
        
        // Desenha a borda superior
        sb.append("┌");
        for (int x = 0; x < width - 2; x++) {
            sb.append("─");
        }
        sb.append("┐\n");
        
        // Desenha o título
        sb.append("│");
        String title = " Estatísticas da Simulação ";
        int padding = (width - 2 - title.length()) / 2;
        for (int i = 0; i < padding; i++) {
            sb.append(" ");
        }
        sb.append(TerminalRenderer.ANSI_CYAN + title + TerminalRenderer.ANSI_RESET);
        for (int i = 0; i < width - 2 - title.length() - padding; i++) {
            sb.append(" ");
        }
        sb.append("│\n");
        
        // Desenha uma linha separadora
        sb.append("├");
        for (int x = 0; x < width - 2; x++) {
            sb.append("─");
        }
        sb.append("┤\n");
        
        // Desenha as estatísticas
        int row = 0;
        for (Map.Entry<String, String> entry : stats.entrySet()) {
            if (row >= height - 3) break; // Limita o número de estatísticas exibidas
            
            sb.append("│ ");
            sb.append(entry.getKey()).append(": ").append(TerminalRenderer.ANSI_YELLOW).append(entry.getValue()).append(TerminalRenderer.ANSI_RESET);
            
            // Preenche o restante da linha com espaços
            int contentLength = entry.getKey().length() + 2 + entry.getValue().length();
            for (int i = 0; i < width - 3 - contentLength; i++) {
                sb.append(" ");
            }
            sb.append("│\n");
            row++;
        }
        
        // Preenche as linhas restantes com espaços
        for (int i = row; i < height - 3; i++) {
            sb.append("│");
            for (int j = 0; j < width - 2; j++) {
                sb.append(" ");
            }
            sb.append("│\n");
        }
        
        // Desenha a borda inferior
        sb.append("└");
        for (int x = 0; x < width - 2; x++) {
            sb.append("─");
        }
        sb.append("┘");
        
        return sb.toString();
    }
}
