# Sistema de Visualização para Simulador de Mobilidade Urbana

Este pacote contém um sistema de visualização avançado para o simulador de mobilidade urbana, utilizando caracteres ASCII/Unicode no terminal.

## Componentes Principais

### TerminalRenderer

Classe principal que gerencia a renderização no terminal. Coordena os diferentes componentes visuais e atualiza a tela.

Principais funcionalidades:
- Limpar a tela e posicionar o cursor
- Renderizar o mapa, estatísticas e logs
- Adicionar e remover veículos
- Adicionar e atualizar semáforos
- Definir células do mapa (ruas, cruzamentos)
- Atualizar estatísticas e logs

### CityMapCanvas

Responsável por renderizar o mapa da cidade usando caracteres Unicode. Representa ruas, cruzamentos, veículos e semáforos.

Principais características:
- Utiliza caracteres Unicode para desenhar ruas e cruzamentos
- Mantém o estado atual do mapa
- Gerencia a posição de veículos e semáforos

### VehicleSymbol

Representa um símbolo de veículo no mapa. Cada veículo é representado por um caractere com uma cor específica.

### TrafficLightSymbol

Representa um símbolo de semáforo no mapa. O semáforo pode estar em um dos três estados: verde, amarelo ou vermelho.

### StatsPanel

Painel que exibe estatísticas da simulação, como número de veículos, tempo de simulação, etc.

### LogPanel

Painel que exibe mensagens de log da simulação em tempo real.

## Exemplo de Uso

A classe `SimulationVisualizer` demonstra como utilizar o sistema de visualização. Ela cria um mapa simples com ruas, cruzamentos, veículos e semáforos, e simula algumas atualizações.

Para executar o exemplo:

```bash
java -cp src/main/java com.simulador.visualizacao.SimulationVisualizer
```

## Integração com o Simulador

Para integrar o sistema de visualização ao simulador de mobilidade urbana:

1. Crie uma instância de `TerminalRenderer` no início da simulação
2. Configure o mapa da cidade usando os métodos `setHorizontalRoad`, `setVerticalRoad`, `setCrossroad`, etc.
3. Adicione veículos e semáforos usando os métodos `addVehicle` e `addTrafficLight`
4. Atualize as estatísticas usando o método `updateStat`
5. Adicione logs usando o método `log`
6. Chame o método `render` a cada ciclo de simulação para atualizar a visualização

## Códigos ANSI e Caracteres Unicode

O sistema utiliza códigos ANSI para cores e formatação, e caracteres Unicode para desenhar o mapa. Os principais códigos estão definidos como constantes na classe `TerminalRenderer`.

### Cores ANSI

- `ANSI_RESET`: Reseta todas as formatações
- `ANSI_BLACK`, `ANSI_RED`, `ANSI_GREEN`, `ANSI_YELLOW`, `ANSI_BLUE`, `ANSI_PURPLE`, `ANSI_CYAN`, `ANSI_WHITE`: Cores de texto
- `ANSI_BLACK_BACKGROUND`, `ANSI_RED_BACKGROUND`, `ANSI_GREEN_BACKGROUND`, etc.: Cores de fundo

### Caracteres Unicode

- `HORIZONTAL_ROAD`: Rua horizontal (━)
- `VERTICAL_ROAD`: Rua vertical (┃)
- `CROSSROAD`: Cruzamento (╋)
- `TOP_LEFT_CORNER`, `TOP_RIGHT_CORNER`, `BOTTOM_LEFT_CORNER`, `BOTTOM_RIGHT_CORNER`: Cantos (┏, ┓, ┗, ┛)
- `T_UP`, `T_DOWN`, `T_LEFT`, `T_RIGHT`: Junções em T (┻, ┳, ┫, ┣)
