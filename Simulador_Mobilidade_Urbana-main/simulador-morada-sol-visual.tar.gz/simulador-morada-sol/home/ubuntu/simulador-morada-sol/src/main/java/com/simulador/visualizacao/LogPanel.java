
package com.simulador.visualizacao;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa um painel de logs.
 * Exibe mensagens de log da simulação em tempo real.
 */
public class LogPanel {
    private int width;
    private int height;
    private List<String> logs;
    private int maxLogs;
    
    /**
     * Construtor do painel de logs
     * 
     * @param width Largura do painel
     * @param height Altura do painel
     */
    public LogPanel(int width, int height) {
        this.width = width;
        this.height = height;
        this.maxLogs = height - 3; // Desconta as bordas e o título
        this.logs = new ArrayList<>();
    }
    
    /**
     * Adiciona uma mensagem de log ao painel
     * 
     * @param message Mensagem a ser adicionada
     */
    public void addLog(String message) {
        logs.add(message);
        
        // Mantém apenas os logs mais recentes
        while (logs.size() > maxLogs) {
            logs.remove(0);
        }
    }
    
    /**
     * Limpa todos os logs do painel
     */
    public void clearLogs() {
        logs.clear();
    }
    
    /**
     * Renderiza o painel de logs
     * 
     * @return String contendo a representação do painel
     */
    public String render() {
        StringBuilder sb = new StringBuilder();
        
        // Desenha a borda superior
        sb.append("┌");
        for (int x = 0; x < width - 2; x++) {
            sb.append("─");
        }
        sb.append("┐\n");
        
        // Desenha o título
        sb.append("│");
        String title = " Logs da Simulação ";
        int padding = (width - 2 - title.length()) / 2;
        for (int i = 0; i < padding; i++) {
            sb.append(" ");
        }
        sb.append(TerminalRenderer.ANSI_CYAN + title + TerminalRenderer.ANSI_RESET);
        for (int i = 0; i < width - 2 - title.length() - padding; i++) {
            sb.append(" ");
        }
        sb.append("│\n");
        
        // Desenha uma linha separadora
        sb.append("├");
        for (int x = 0; x < width - 2; x++) {
            sb.append("─");
        }
        sb.append("┤\n");
        
        // Desenha os logs
        int startIndex = Math.max(0, logs.size() - maxLogs);
        for (int i = startIndex; i < logs.size(); i++) {
            String log = logs.get(i);
            
            // Trunca a mensagem se for muito longa
            if (log.length() > width - 4) {
                log = log.substring(0, width - 7) + "...";
            }
            
            sb.append("│ ");
            sb.append(log);
            
            // Preenche o restante da linha com espaços
            for (int j = 0; j < width - 3 - log.length(); j++) {
                sb.append(" ");
            }
            sb.append("│\n");
        }
        
        // Preenche as linhas restantes com espaços
        for (int i = logs.size() - startIndex; i < maxLogs; i++) {
            sb.append("│");
            for (int j = 0; j < width - 2; j++) {
                sb.append(" ");
            }
            sb.append("│\n");
        }
        
        // Desenha a borda inferior
        sb.append("└");
        for (int x = 0; x < width - 2; x++) {
            sb.append("─");
        }
        sb.append("┘");
        
        return sb.toString();
    }
}
