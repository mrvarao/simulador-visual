
package com.simulador.estatisticas;

import java.util.Map;

/**
 * Interface que define o comportamento básico de um coletor de estatísticas.
 * Responsável por coletar e armazenar dados estatísticos durante a simulação.
 */
public interface EstatisticasColetor {
    
    /**
     * Inicializa o coletor de estatísticas.
     */
    void inicializar();
    
    /**
     * Registra o início de uma viagem de veículo.
     * 
     * @param idVeiculo Identificador único do veículo
     * @param origem Coordenadas de origem (x, y)
     * @param destino Coordenadas de destino (x, y)
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarInicioViagem(String idVeiculo, int[] origem, int[] destino, int tempoSimulacao);
    
    /**
     * Registra o fim de uma viagem de veículo.
     * 
     * @param idVeiculo Identificador único do veículo
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarFimViagem(String idVeiculo, int tempoSimulacao);
    
    /**
     * Registra a parada de um veículo em um semáforo.
     * 
     * @param idVeiculo Identificador único do veículo
     * @param idSemaforo Identificador único do semáforo
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarParadaSemaforo(String idVeiculo, int idSemaforo, int tempoSimulacao);
    
    /**
     * Registra a partida de um veículo de um semáforo.
     * 
     * @param idVeiculo Identificador único do veículo
     * @param idSemaforo Identificador único do semáforo
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarPartidaSemaforo(String idVeiculo, int idSemaforo, int tempoSimulacao);
    
    /**
     * Registra a mudança de estado de um semáforo.
     * 
     * @param idSemaforo Identificador único do semáforo
     * @param estadoAnterior Estado anterior do semáforo
     * @param novoEstado Novo estado do semáforo
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarMudancaEstadoSemaforo(int idSemaforo, String estadoAnterior, String novoEstado, int tempoSimulacao);
    
    /**
     * Registra o fluxo de veículos em um ponto específico da cidade.
     * 
     * @param coordenadas Coordenadas do ponto (x, y)
     * @param fluxo Número de veículos que passaram pelo ponto
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarFluxoVeiculos(int[] coordenadas, int fluxo, int tempoSimulacao);
    
    /**
     * Registra o consumo energético de um semáforo.
     * 
     * @param idSemaforo Identificador único do semáforo
     * @param consumo Consumo energético em unidades arbitrárias
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarConsumoEnergetico(int idSemaforo, double consumo, int tempoSimulacao);
    
    /**
     * Registra o nível de congestionamento em um ponto específico da cidade.
     * 
     * @param coordenadas Coordenadas do ponto (x, y)
     * @param nivel Nível de congestionamento (0-100)
     * @param tempoSimulacao Tempo atual da simulação em segundos
     */
    void registrarCongestionamento(int[] coordenadas, int nivel, int tempoSimulacao);
    
    /**
     * Obtém as estatísticas coletadas.
     * 
     * @return Mapa com as estatísticas coletadas
     */
    Map<String, Object> getEstatisticas();
    
    /**
     * Gera um relatório com as estatísticas coletadas.
     * 
     * @return Relatório formatado
     */
    String gerarRelatorio();
    
    /**
     * Gera um relatório comparativo entre diferentes modelos de controle de semáforos.
     * 
     * @param coletores Lista de coletores de estatísticas para comparação
     * @return Relatório comparativo formatado
     */
    static String gerarRelatorioComparativo(EstatisticasColetor[] coletores) {
        return RelatorioComparativo.gerar(coletores);
    }
    
    /**
     * Limpa todas as estatísticas coletadas.
     */
    void limpar();
}
