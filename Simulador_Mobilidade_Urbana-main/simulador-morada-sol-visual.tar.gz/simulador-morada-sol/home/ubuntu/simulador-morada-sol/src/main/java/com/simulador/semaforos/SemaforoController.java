
package com.simulador.semaforos;

import com.simulador.visualizacao.TrafficLightSymbol;

/**
 * Interface que define o comportamento básico de um controlador de semáforos.
 * Todos os modelos de controle de semáforos devem implementar esta interface.
 */
public interface SemaforoController {
    
    /**
     * Inicializa o controlador de semáforos.
     */
    void inicializar();
    
    /**
     * Atualiza o estado dos semáforos com base no modelo de controle implementado.
     * 
     * @param tempoSimulacao Tempo atual da simulação em segundos
     * @param fluxoVeiculos Mapa de fluxo de veículos por semáforo (id do semáforo -> número de veículos)
     */
    void atualizar(int tempoSimulacao, java.util.Map<Integer, Integer> fluxoVeiculos);
    
    /**
     * Obtém o estado atual de um semáforo específico.
     * 
     * @param idSemaforo Identificador único do semáforo
     * @return Estado atual do semáforo
     */
    TrafficLightSymbol.State getEstadoSemaforo(int idSemaforo);
    
    /**
     * Obtém o tempo restante para a próxima mudança de estado de um semáforo específico.
     * 
     * @param idSemaforo Identificador único do semáforo
     * @return Tempo restante em segundos
     */
    int getTempoRestante(int idSemaforo);
    
    /**
     * Obtém estatísticas de desempenho do controlador.
     * 
     * @return Mapa com estatísticas (nome da estatística -> valor)
     */
    java.util.Map<String, String> getEstatisticas();
    
    /**
     * Obtém o nome do modelo de controle.
     * 
     * @return Nome do modelo
     */
    String getNomeModelo();
}
