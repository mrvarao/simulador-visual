
package com.simulador.principal;

import com.simulador.estatisticas.EstatisticasColetor;
import com.simulador.estatisticas.EstatisticasColetorImpl;
import com.simulador.estruturas.Grafo;
import com.simulador.semaforos.SemaforoController;
import com.simulador.semaforos.SemaforoFactory;
import com.simulador.visualizacao.TerminalRenderer;
import com.simulador.visualizacao.TrafficLightSymbol;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Classe principal do simulador de mobilidade urbana para o bairro Morada do Sol.
 * Responsável por integrar todos os componentes e executar a simulação.
 */
public class SimuladorMain {
    
    // Componentes principais do simulador
    private Grafo cidade;
    private SemaforoController controladorSemaforos;
    private TerminalRenderer visualizador;
    private EstatisticasColetor coletorEstatisticas;
    
    // Configurações da simulação
    private ConfiguracaoSimulacao config;
    
    // Estado da simulação
    private int tempoSimulacao;
    private boolean simulacaoAtiva;
    private Map<String, Veiculo> veiculos;
    private Map<Integer, Integer> fluxoVeiculos; // idSemaforo -> quantidade de veículos
    
    /**
     * Construtor da classe principal do simulador.
     * 
     * @param config Configurações da simulação
     */
    public SimuladorMain(ConfiguracaoSimulacao config) {
        this.config = config;
        this.tempoSimulacao = 0;
        this.simulacaoAtiva = false;
        this.veiculos = new HashMap<>();
        this.fluxoVeiculos = new HashMap<>();
    }
    
    /**
     * Inicializa todos os componentes do simulador.
     */
    public void inicializar() {
        // Inicializa o grafo da cidade
        inicializarCidade();
        
        // Inicializa o controlador de semáforos
        inicializarSemaforos();
        
        // Inicializa o sistema de visualização
        inicializarVisualizacao();
        
        // Inicializa o coletor de estatísticas
        inicializarEstatisticas();
        
        // Inicializa os veículos
        inicializarVeiculos();
        
        // Exibe mensagem de inicialização
        visualizador.log("Simulador do bairro Morada do Sol inicializado com sucesso!");
        visualizador.log("Modelo de controle de semáforos: " + controladorSemaforos.getNomeModelo());
        visualizador.log("Duração da simulação: " + config.getDuracaoSimulacao() + " segundos");
        visualizador.log("Número inicial de veículos: " + config.getNumeroInicialVeiculos());
        
        // Atualiza estatísticas iniciais
        atualizarEstatisticasVisualizacao();
        
        // Renderiza o estado inicial
        visualizador.render();
    }
    
    /**
     * Inicializa o grafo que representa a cidade.
     */
    private void inicializarCidade() {
        cidade = new Grafo();
        
        // Cria o bairro Morada do Sol
        MoradaDoSolFactory.criarBairro(cidade, config.getTamanhoCidade());
    }
    
    /**
     * Inicializa o controlador de semáforos.
     */
    private void inicializarSemaforos() {
        // Cria o controlador de semáforos (sempre usa o modelo de otimização do tempo de espera)
        controladorSemaforos = SemaforoFactory.criarControlador(SemaforoFactory.TipoControlador.TEMPO_ESPERA);
        controladorSemaforos.inicializar();
    }
    
    /**
     * Inicializa o sistema de visualização.
     */
    private void inicializarVisualizacao() {
        // Cria o renderizador de terminal com base no tamanho da cidade
        int larguraMapa = config.getTamanhoCidade()[0];
        int alturaMapa = config.getTamanhoCidade()[1];
        int larguraTerminal = Math.max(100, larguraMapa * 2 + 40);
        int alturaTerminal = Math.max(30, alturaMapa * 2 + 10);
        
        visualizador = new TerminalRenderer(larguraMapa, alturaMapa, larguraTerminal, alturaTerminal);
        visualizador.start();
        
        // Cria o mapa visual do bairro Morada do Sol
        MoradaDoSolFactory.criarMapaVisual(visualizador, config.getTamanhoCidade());
        
        // Adiciona os semáforos ao visualizador com estados aleatórios
        Map<Integer, int[]> posicoesSemaforos = MoradaDoSolFactory.getPosicoesSemaforos();
        for (Map.Entry<Integer, int[]> entry : posicoesSemaforos.entrySet()) {
            int idSemaforo = entry.getKey();
            int[] posicao = entry.getValue();
            
            // Gera um estado aleatório para o semáforo
            TrafficLightSymbol.State estadoAleatorio = MoradaDoSolFactory.gerarEstadoAleatorio();
            
            // Adiciona o semáforo ao visualizador
            visualizador.addTrafficLight(posicao[0], posicao[1], estadoAleatorio);
            
            // Inicializa o fluxo de veículos para este semáforo
            fluxoVeiculos.put(idSemaforo, 0);
            
            // Exibe informação sobre o semáforo
            String nomeRua = MoradaDoSolFactory.getNomeRua(idSemaforo);
            visualizador.log("Semáforo " + idSemaforo + " em " + nomeRua + " - Estado inicial: " + estadoAleatorio);
        }
    }
    
    /**
     * Inicializa o coletor de estatísticas.
     */
    private void inicializarEstatisticas() {
        coletorEstatisticas = new EstatisticasColetorImpl(controladorSemaforos.getNomeModelo());
        coletorEstatisticas.inicializar();
    }
    
    /**
     * Inicializa os veículos da simulação.
     */
    private void inicializarVeiculos() {
        // Cria veículos iniciais com base na configuração
        for (int i = 0; i < config.getNumeroInicialVeiculos(); i++) {
            adicionarNovoVeiculo();
        }
    }
    
    /**
     * Adiciona um novo veículo à simulação.
     */
    private void adicionarNovoVeiculo() {
        // Gera um ID único para o veículo
        String idVeiculo = "V" + (veiculos.size() + 1);
        
        // Gera origem e destino aleatórios
        int[] origem = MoradaDoSolFactory.gerarPosicaoAleatoria(config.getTamanhoCidade());
        int[] destino = MoradaDoSolFactory.gerarPosicaoAleatoria(config.getTamanhoCidade());
        
        // Cria o veículo
        Veiculo veiculo = new Veiculo(idVeiculo, origem, destino);
        veiculos.put(idVeiculo, veiculo);
        
        // Adiciona o veículo ao visualizador
        visualizador.addVehicle(origem[0], origem[1], idVeiculo.charAt(0), TerminalRenderer.ANSI_BLUE);
        
        // Registra o início da viagem nas estatísticas
        coletorEstatisticas.registrarInicioViagem(idVeiculo, origem, destino, tempoSimulacao);
        
        // Log
        visualizador.log("Veículo " + idVeiculo + " adicionado na posição (" + origem[0] + "," + origem[1] + ")");
    }
    
    /**
     * Executa a simulação pelo tempo configurado.
     */
    public void executar() {
        simulacaoAtiva = true;
        
        visualizador.log("Iniciando simulação do bairro Morada do Sol...");
        
        // Loop principal da simulação
        while (simulacaoAtiva && tempoSimulacao < config.getDuracaoSimulacao()) {
            // Incrementa o tempo de simulação
            tempoSimulacao++;
            
            try {
                // Atualiza o estado dos semáforos
                atualizarSemaforos();
                
                // Atualiza o estado dos veículos
                atualizarVeiculos();
                
                // Atualiza as estatísticas na visualização
                atualizarEstatisticasVisualizacao();
                
                // Renderiza o estado atual
                visualizador.render();
                
                // Pausa para visualização
                TimeUnit.MILLISECONDS.sleep(config.getVelocidadeSimulacao());
            } catch (InterruptedException e) {
                visualizador.log("Simulação interrompida: " + e.getMessage());
                break;
            }
        }
        
        // Finaliza a simulação
        finalizar();
    }
    
    /**
     * Atualiza o estado dos semáforos.
     */
    private void atualizarSemaforos() {
        // Atualiza o controlador de semáforos com o fluxo atual
        controladorSemaforos.atualizar(tempoSimulacao, fluxoVeiculos);
        
        // Atualiza a visualização dos semáforos
        Map<Integer, int[]> posicoesSemaforos = MoradaDoSolFactory.getPosicoesSemaforos();
        for (Map.Entry<Integer, int[]> entry : posicoesSemaforos.entrySet()) {
            int idSemaforo = entry.getKey();
            int[] posicao = entry.getValue();
            
            // Obtém o estado atual do semáforo
            TrafficLightSymbol.State estado = controladorSemaforos.getEstadoSemaforo(idSemaforo);
            
            // Atualiza o semáforo no visualizador
            visualizador.updateTrafficLight(posicao[0], posicao[1], estado);
            
            // Registra o consumo energético nas estatísticas
            // Valores de consumo: VERDE = 1.0, AMARELO = 0.8, VERMELHO = 0.5
            double consumo = 0.5; // Padrão para VERMELHO
            if (estado == TrafficLightSymbol.State.GREEN) {
                consumo = 1.0;
            } else if (estado == TrafficLightSymbol.State.YELLOW) {
                consumo = 0.8;
            }
            
            coletorEstatisticas.registrarConsumoEnergetico(idSemaforo, consumo, tempoSimulacao);
        }
        
        // Reseta o fluxo de veículos para o próximo ciclo
        for (Integer idSemaforo : fluxoVeiculos.keySet()) {
            fluxoVeiculos.put(idSemaforo, 0);
        }
    }
    
    /**
     * Atualiza o estado dos veículos.
     */
    private void atualizarVeiculos() {
        // Para cada veículo ativo
        for (Veiculo veiculo : veiculos.values()) {
            if (!veiculo.isAtivo()) continue;
            
            // Posição atual do veículo
            int[] posicaoAtual = veiculo.getPosicaoAtual();
            
            // Remove o veículo da posição atual no visualizador
            visualizador.removeVehicle(posicaoAtual[0], posicaoAtual[1]);
            
            // Verifica se o veículo chegou ao destino
            if (veiculo.chegouAoDestino()) {
                veiculo.setAtivo(false);
                coletorEstatisticas.registrarFimViagem(veiculo.getId(), tempoSimulacao);
                visualizador.log("Veículo " + veiculo.getId() + " chegou ao destino");
                continue;
            }
            
            // Verifica se o veículo está em um semáforo
            Integer idSemaforo = MoradaDoSolFactory.getSemaforoEmPosicao(posicaoAtual);
            if (idSemaforo != null) {
                // Incrementa o fluxo de veículos neste semáforo
                fluxoVeiculos.put(idSemaforo, fluxoVeiculos.get(idSemaforo) + 1);
                
                // Verifica o estado do semáforo
                TrafficLightSymbol.State estadoSemaforo = controladorSemaforos.getEstadoSemaforo(idSemaforo);
                
                if (estadoSemaforo == TrafficLightSymbol.State.RED || estadoSemaforo == TrafficLightSymbol.State.YELLOW) {
                    // Se o semáforo estiver vermelho ou amarelo, o veículo para
                    if (!veiculo.isParado()) {
                        veiculo.parar();
                        coletorEstatisticas.registrarParadaSemaforo(veiculo.getId(), idSemaforo, tempoSimulacao);
                    }
                    
                    // Adiciona o veículo de volta na mesma posição
                    visualizador.addVehicle(posicaoAtual[0], posicaoAtual[1], veiculo.getId().charAt(0), TerminalRenderer.ANSI_RED);
                    continue;
                } else if (veiculo.isParado()) {
                    // Se o semáforo estiver verde e o veículo estava parado, ele parte
                    veiculo.partir();
                    coletorEstatisticas.registrarPartidaSemaforo(veiculo.getId(), idSemaforo, tempoSimulacao);
                }
            }
            
            // Move o veículo para a próxima posição
            int[] novaPosicao = veiculo.mover();
            
            // Adiciona o veículo na nova posição no visualizador
            visualizador.addVehicle(novaPosicao[0], novaPosicao[1], veiculo.getId().charAt(0), TerminalRenderer.ANSI_GREEN);
            
            // Registra o fluxo de veículos nas estatísticas
            coletorEstatisticas.registrarFluxoVeiculos(novaPosicao, 1, tempoSimulacao);
            
            // Calcula e registra o nível de congestionamento
            int nivelCongestionamento = calcularCongestionamento(novaPosicao);
            coletorEstatisticas.registrarCongestionamento(novaPosicao, nivelCongestionamento, tempoSimulacao);
        }
        
        // Adiciona novos veículos se necessário
        if (veiculos.size() < config.getNumeroMaximoVeiculos() && Math.random() < config.getTaxaGeracaoVeiculos()) {
            adicionarNovoVeiculo();
        }
    }
    
    /**
     * Calcula o nível de congestionamento em uma posição.
     * 
     * @param posicao Posição a ser verificada
     * @return Nível de congestionamento (0-100)
     */
    private int calcularCongestionamento(int[] posicao) {
        // Conta quantos veículos estão próximos à posição
        int veiculosProximos = 0;
        
        for (Veiculo veiculo : veiculos.values()) {
            if (!veiculo.isAtivo()) continue;
            
            int[] posicaoVeiculo = veiculo.getPosicaoAtual();
            double distancia = Math.sqrt(
                Math.pow(posicaoVeiculo[0] - posicao[0], 2) +
                Math.pow(posicaoVeiculo[1] - posicao[1], 2)
            );
            
            if (distancia < 3) {
                veiculosProximos++;
            }
        }
        
        // Calcula o nível de congestionamento (0-100)
        return Math.min(100, veiculosProximos * 20);
    }
    
    /**
     * Atualiza as estatísticas na visualização.
     */
    private void atualizarEstatisticasVisualizacao() {
        // Formata o tempo de simulação (mm:ss)
        int minutos = tempoSimulacao / 60;
        int segundos = tempoSimulacao % 60;
        String tempoFormatado = String.format("%02d:%02d", minutos, segundos);
        
        // Atualiza as estatísticas no visualizador
        visualizador.updateStat("Tempo de Simulação", tempoFormatado);
        visualizador.updateStat("Veículos Ativos", String.valueOf(contarVeiculosAtivos()));
        visualizador.updateStat("Modelo de Controle", controladorSemaforos.getNomeModelo());
        visualizador.updateStat("Bairro", "Morada do Sol - Teresina");
        
        // Adiciona estatísticas do controlador de semáforos
        Map<String, String> estatisticasControlador = controladorSemaforos.getEstatisticas();
        for (Map.Entry<String, String> entry : estatisticasControlador.entrySet()) {
            visualizador.updateStat(entry.getKey(), entry.getValue());
        }
        
        // Adiciona estatísticas de congestionamento
        int congestionamentoMedio = calcularCongestionamentoMedio();
        visualizador.updateStat("Congestionamento Médio", congestionamentoMedio + "%");
    }
    
    /**
     * Calcula o congestionamento médio em toda a cidade.
     * 
     * @return Nível médio de congestionamento (0-100)
     */
    private int calcularCongestionamentoMedio() {
        int totalCongestionamento = 0;
        int pontosMedidos = 0;
        
        // Amostra pontos na cidade para calcular o congestionamento
        for (int x = 0; x < config.getTamanhoCidade()[0]; x += 5) {
            for (int y = 0; y < config.getTamanhoCidade()[1]; y += 5) {
                int congestionamento = calcularCongestionamento(new int[]{x, y});
                totalCongestionamento += congestionamento;
                pontosMedidos++;
            }
        }
        
        // Calcula a média
        return pontosMedidos > 0 ? totalCongestionamento / pontosMedidos : 0;
    }
    
    /**
     * Conta o número de veículos ativos na simulação.
     * 
     * @return Número de veículos ativos
     */
    private int contarVeiculosAtivos() {
        int count = 0;
        for (Veiculo veiculo : veiculos.values()) {
            if (veiculo.isAtivo()) {
                count++;
            }
        }
        return count;
    }
    
    /**
     * Finaliza a simulação e gera relatórios.
     */
    private void finalizar() {
        simulacaoAtiva = false;
        
        visualizador.log("Simulação finalizada após " + tempoSimulacao + " segundos");
        visualizador.log("Gerando relatório de estatísticas...");
        
        // Gera o relatório de estatísticas
        String relatorio = coletorEstatisticas.gerarRelatorio();
        
        // Salva o relatório em um arquivo
        String nomeArquivo = "relatorio_morada_sol_" + controladorSemaforos.getNomeModelo().replace(" ", "_").toLowerCase() + ".txt";
        RelatorioExportador.salvarRelatorio(relatorio, nomeArquivo);
        
        visualizador.log("Relatório salvo em: " + nomeArquivo);
        
        // Aguarda um pouco antes de encerrar o visualizador
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            // Ignora
        }
        
        // Para o visualizador
        visualizador.stop();
    }
    
    /**
     * Método principal para execução do simulador.
     * 
     * @param args Argumentos da linha de comando
     */
    public static void main(String[] args) {
        // Cria a interface de configuração
        ConfigCLI configCLI = new ConfigCLI();
        
        // Obtém as configurações do usuário
        ConfiguracaoSimulacao config = configCLI.obterConfiguracoes();
        
        // Verifica se há uma propriedade do sistema que define a duração da simulação
        String duracaoProperty = System.getProperty("simulacao.duracao");
        if (duracaoProperty != null) {
            try {
                int duracao = Integer.parseInt(duracaoProperty);
                config.setDuracaoSimulacao(duracao);
                System.out.println("Duração da simulação definida por propriedade do sistema: " + duracao + " segundos");
            } catch (NumberFormatException e) {
                System.out.println("Valor inválido para simulacao.duracao: " + duracaoProperty);
            }
        }
        
        // Cria e inicializa o simulador
        SimuladorMain simulador = new SimuladorMain(config);
        simulador.inicializar();
        
        // Executa a simulação
        simulador.executar();
    }
}
