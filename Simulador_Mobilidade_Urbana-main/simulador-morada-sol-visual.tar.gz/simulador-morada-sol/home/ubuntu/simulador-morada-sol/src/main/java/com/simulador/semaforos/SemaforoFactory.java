
package com.simulador.semaforos;

/**
 * Fábrica para criar instâncias dos controladores de semáforos.
 * Nesta versão, apenas o modelo de otimização do tempo de espera está disponível.
 */
public class SemaforoFactory {
    
    /**
     * Tipos de controladores disponíveis
     * Nesta versão, apenas TEMPO_ESPERA está disponível
     */
    public enum TipoControlador {
        TEMPO_ESPERA
    }
    
    /**
     * Cria e retorna uma instância do controlador de semáforos.
     * Nesta versão, sempre retorna o controlador de otimização do tempo de espera.
     * 
     * @param tipo Tipo de controlador a ser criado (ignorado nesta versão)
     * @return Instância do controlador de semáforos de otimização do tempo de espera
     */
    public static SemaforoController criarControlador(TipoControlador tipo) {
        // Sempre cria o controlador de otimização do tempo de espera
        SemaforoController controlador = new TempoEsperaController();
        
        // Inicializa o controlador
        controlador.inicializar();
        
        return controlador;
    }
}
