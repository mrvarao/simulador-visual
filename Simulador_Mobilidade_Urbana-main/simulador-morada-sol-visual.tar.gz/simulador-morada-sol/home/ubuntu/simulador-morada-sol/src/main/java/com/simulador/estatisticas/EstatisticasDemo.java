
package com.simulador.estatisticas;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Classe de demonstração para testar o sistema de estatísticas.
 * Esta classe cria uma simulação simples para mostrar o funcionamento do sistema.
 */
public class EstatisticasDemo {
    
    /**
     * Método principal para demonstração
     * 
     * @param args Argumentos da linha de comando
     * @throws InterruptedException Se a thread for interrompida durante o sleep
     */
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Iniciando demonstração do sistema de estatísticas...");
        
        // Cria coletores de estatísticas para cada modelo de controle
        EstatisticasColetor coletorCicloFixo = new EstatisticasColetorImpl("Ciclo Fixo");
        EstatisticasColetor coletorTempoEspera = new EstatisticasColetorImpl("Tempo de Espera");
        EstatisticasColetor coletorEnergia = new EstatisticasColetorImpl("Energia");
        
        // Inicializa os coletores
        coletorCicloFixo.inicializar();
        coletorTempoEspera.inicializar();
        coletorEnergia.inicializar();
        
        // Não precisamos criar controladores reais para a demonstração
        // Apenas simulamos os dados que seriam coletados
        
        // Simula o fluxo de veículos (valores arbitrários para demonstração)
        Map<Integer, Integer> fluxoVeiculos = new HashMap<>();
        fluxoVeiculos.put(1, 10); // Semáforo 1 tem 10 veículos/min
        fluxoVeiculos.put(2, 5);  // Semáforo 2 tem 5 veículos/min
        fluxoVeiculos.put(3, 15); // Semáforo 3 tem 15 veículos/min
        fluxoVeiculos.put(4, 8);  // Semáforo 4 tem 8 veículos/min
        
        // Gera dados aleatórios para demonstração
        Random random = new Random(42); // Seed fixo para reprodutibilidade
        
        // Simula algumas viagens
        for (int i = 1; i <= 50; i++) {
            String idVeiculo = "V" + i;
            int[] origem = {random.nextInt(30), random.nextInt(15)};
            int[] destino = {random.nextInt(30), random.nextInt(15)};
            int tempoInicio = random.nextInt(60);
            
            // Registra o início da viagem em todos os coletores
            coletorCicloFixo.registrarInicioViagem(idVeiculo, origem, destino, tempoInicio);
            coletorTempoEspera.registrarInicioViagem(idVeiculo, origem, destino, tempoInicio);
            coletorEnergia.registrarInicioViagem(idVeiculo, origem, destino, tempoInicio);
            
            // Simula algumas paradas em semáforos
            int numParadas = 1 + random.nextInt(3);
            for (int j = 0; j < numParadas; j++) {
                int idSemaforo = 1 + random.nextInt(4);
                int tempoParada = tempoInicio + 10 + random.nextInt(50);
                
                // Registra a parada em todos os coletores
                coletorCicloFixo.registrarParadaSemaforo(idVeiculo, idSemaforo, tempoParada);
                coletorTempoEspera.registrarParadaSemaforo(idVeiculo, idSemaforo, tempoParada);
                coletorEnergia.registrarParadaSemaforo(idVeiculo, idSemaforo, tempoParada);
                
                // Simula o tempo de espera
                int tempoEspera = 5 + random.nextInt(20);
                int tempoPartida = tempoParada + tempoEspera;
                
                // Registra a partida em todos os coletores
                coletorCicloFixo.registrarPartidaSemaforo(idVeiculo, idSemaforo, tempoPartida);
                coletorTempoEspera.registrarPartidaSemaforo(idVeiculo, idSemaforo, tempoPartida);
                coletorEnergia.registrarPartidaSemaforo(idVeiculo, idSemaforo, tempoPartida);
            }
            
            // Registra o fim da viagem
            int tempoFim = tempoInicio + 60 + random.nextInt(120);
            
            coletorCicloFixo.registrarFimViagem(idVeiculo, tempoFim);
            coletorTempoEspera.registrarFimViagem(idVeiculo, tempoFim);
            coletorEnergia.registrarFimViagem(idVeiculo, tempoFim);
        }
        
        // Simula o consumo energético dos semáforos
        for (int i = 1; i <= 4; i++) {
            // Ciclo Fixo: consumo constante
            double consumoCicloFixo = 10.0;
            
            // Tempo de Espera: consumo variável baseado no fluxo
            double consumoTempoEspera = 5.0 + (fluxoVeiculos.get(i) * 0.5);
            
            // Energia: consumo otimizado
            double consumoEnergia = 3.0 + (fluxoVeiculos.get(i) * 0.3);
            
            coletorCicloFixo.registrarConsumoEnergetico(i, consumoCicloFixo, 100);
            coletorTempoEspera.registrarConsumoEnergetico(i, consumoTempoEspera, 100);
            coletorEnergia.registrarConsumoEnergetico(i, consumoEnergia, 100);
        }
        
        // Simula o fluxo de veículos em diferentes pontos
        for (int x = 0; x < 30; x += 10) {
            for (int y = 0; y < 15; y += 5) {
                int[] coordenadas = {x, y};
                
                // Fluxo diferente para cada modelo
                int fluxoCicloFixo = 10 + random.nextInt(20);
                int fluxoTempoEspera = 15 + random.nextInt(25);
                int fluxoEnergia = 12 + random.nextInt(18);
                
                coletorCicloFixo.registrarFluxoVeiculos(coordenadas, fluxoCicloFixo, 100);
                coletorTempoEspera.registrarFluxoVeiculos(coordenadas, fluxoTempoEspera, 100);
                coletorEnergia.registrarFluxoVeiculos(coordenadas, fluxoEnergia, 100);
            }
        }
        
        // Simula o nível de congestionamento em diferentes pontos
        for (int x = 0; x < 30; x += 10) {
            for (int y = 0; y < 15; y += 5) {
                int[] coordenadas = {x, y};
                
                // Nível de congestionamento diferente para cada modelo
                int nivelCicloFixo = 30 + random.nextInt(50);
                int nivelTempoEspera = 20 + random.nextInt(40);
                int nivelEnergia = 25 + random.nextInt(45);
                
                coletorCicloFixo.registrarCongestionamento(coordenadas, nivelCicloFixo, 100);
                coletorTempoEspera.registrarCongestionamento(coordenadas, nivelTempoEspera, 100);
                coletorEnergia.registrarCongestionamento(coordenadas, nivelEnergia, 100);
            }
        }
        
        // Gera relatórios individuais
        System.out.println("\n\n=== RELATÓRIO DO MODELO CICLO FIXO ===");
        System.out.println(coletorCicloFixo.gerarRelatorio());
        
        System.out.println("\n\n=== RELATÓRIO DO MODELO TEMPO DE ESPERA ===");
        System.out.println(coletorTempoEspera.gerarRelatorio());
        
        System.out.println("\n\n=== RELATÓRIO DO MODELO ENERGIA ===");
        System.out.println(coletorEnergia.gerarRelatorio());
        
        // Gera relatório comparativo
        System.out.println("\n\n=== RELATÓRIO COMPARATIVO ===");
        EstatisticasColetor[] coletores = {coletorCicloFixo, coletorTempoEspera, coletorEnergia};
        System.out.println(EstatisticasColetor.gerarRelatorioComparativo(coletores));
        
        System.out.println("Demonstração concluída!");
    }
}
