
package com.simulador.estatisticas;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Classe responsável por gerar relatórios comparativos entre diferentes modelos de controle de semáforos.
 */
public class RelatorioComparativo {
    
    /**
     * Gera um relatório comparativo entre diferentes modelos de controle de semáforos.
     * 
     * @param coletores Lista de coletores de estatísticas para comparação
     * @return Relatório comparativo formatado
     */
    public static String gerar(EstatisticasColetor[] coletores) {
        if (coletores == null || coletores.length == 0) {
            return "Nenhum coletor de estatísticas disponível para comparação.";
        }
        
        StringBuilder sb = new StringBuilder();
        
        // Cabeçalho do relatório
        sb.append("=".repeat(100)).append("\n");
        sb.append(" RELATÓRIO COMPARATIVO - MODELOS DE CONTROLE DE SEMÁFOROS\n");
        sb.append("=".repeat(100)).append("\n\n");
        
        // Lista de modelos
        sb.append("MODELOS COMPARADOS:\n");
        for (int i = 0; i < coletores.length; i++) {
            Map<String, Object> estatisticas = coletores[i].getEstatisticas();
            sb.append(String.format("%d. %s\n", i + 1, estatisticas.get("modelo_controle")));
        }
        sb.append("\n");
        
        // Tabela comparativa
        sb.append("TABELA COMPARATIVA:\n");
        sb.append("-".repeat(100)).append("\n");
        
        // Cabeçalho da tabela
        sb.append(String.format("%-30s", "Métrica"));
        for (EstatisticasColetor coletor : coletores) {
            Map<String, Object> estatisticas = coletor.getEstatisticas();
            sb.append(String.format(" | %-20s", estatisticas.get("modelo_controle")));
        }
        sb.append("\n");
        sb.append("-".repeat(100)).append("\n");
        
        // Métricas para comparação
        String[] metricas = {
            "tempo_medio_viagem",
            "tempo_medio_espera_semaforos",
            "percentual_tempo_espera",
            "consumo_energetico_total",
            "consumo_energetico_medio",
            "nivel_medio_congestionamento",
            "fluxo_total_veiculos"
        };
        
        String[] nomeMetricas = {
            "Tempo Médio de Viagem (s)",
            "Tempo Médio de Espera (s)",
            "Percentual de Tempo em Espera (%)",
            "Consumo Energético Total",
            "Consumo Energético Médio",
            "Nível Médio de Congestionamento (%)",
            "Fluxo Total de Veículos"
        };
        
        // Linhas da tabela
        for (int i = 0; i < metricas.length; i++) {
            sb.append(String.format("%-30s", nomeMetricas[i]));
            
            for (EstatisticasColetor coletor : coletores) {
                Map<String, Object> estatisticas = coletor.getEstatisticas();
                Object valor = estatisticas.get(metricas[i]);
                
                if (valor instanceof Double) {
                    sb.append(String.format(" | %-20.2f", (Double) valor));
                } else if (valor instanceof Integer) {
                    sb.append(String.format(" | %-20d", (Integer) valor));
                } else {
                    sb.append(String.format(" | %-20s", "N/A"));
                }
            }
            
            sb.append("\n");
        }
        
        sb.append("-".repeat(100)).append("\n\n");
        
        // Gráficos comparativos
        sb.append("GRÁFICOS COMPARATIVOS:\n\n");
        
        // Gráfico de tempo médio de viagem
        sb.append("TEMPO MÉDIO DE VIAGEM (segundos)\n");
        sb.append("-".repeat(100)).append("\n");
        gerarGraficoComparativo(sb, coletores, "tempo_medio_viagem", 60);
        sb.append("\n");
        
        // Gráfico de tempo médio de espera
        sb.append("TEMPO MÉDIO DE ESPERA EM SEMÁFOROS (segundos)\n");
        sb.append("-".repeat(100)).append("\n");
        gerarGraficoComparativo(sb, coletores, "tempo_medio_espera_semaforos", 60);
        sb.append("\n");
        
        // Gráfico de consumo energético
        sb.append("CONSUMO ENERGÉTICO TOTAL\n");
        sb.append("-".repeat(100)).append("\n");
        gerarGraficoComparativo(sb, coletores, "consumo_energetico_total", 60);
        sb.append("\n");
        
        // Gráfico de nível de congestionamento
        sb.append("NÍVEL MÉDIO DE CONGESTIONAMENTO (%)\n");
        sb.append("-".repeat(100)).append("\n");
        gerarGraficoComparativo(sb, coletores, "nivel_medio_congestionamento", 60);
        sb.append("\n");
        
        // Análise e recomendações
        sb.append("ANÁLISE E RECOMENDAÇÕES:\n");
        sb.append("-".repeat(100)).append("\n");
        
        // Encontra o melhor modelo para cada métrica
        for (int i = 0; i < metricas.length; i++) {
            String metrica = metricas[i];
            String nomeMetrica = nomeMetricas[i];
            
            int melhorIndice = encontrarMelhorModelo(coletores, metrica);
            
            if (melhorIndice >= 0) {
                Map<String, Object> estatisticas = coletores[melhorIndice].getEstatisticas();
                String melhorModelo = (String) estatisticas.get("modelo_controle");
                
                sb.append(String.format("- Para otimizar %s, o modelo %s apresenta o melhor desempenho.\n", 
                        nomeMetrica.toLowerCase(), melhorModelo));
            }
        }
        
        // Recomendação geral
        int melhorModeloGeral = encontrarMelhorModeloGeral(coletores, metricas);
        if (melhorModeloGeral >= 0) {
            Map<String, Object> estatisticas = coletores[melhorModeloGeral].getEstatisticas();
            String melhorModelo = (String) estatisticas.get("modelo_controle");
            
            sb.append("\nRECOMENDAÇÃO GERAL:\n");
            sb.append(String.format("Com base na análise comparativa, o modelo %s apresenta o melhor equilíbrio " +
                    "entre tempo de viagem, consumo energético e fluxo de veículos.\n", melhorModelo));
        }
        
        // Rodapé do relatório
        sb.append("\n");
        sb.append("=".repeat(100)).append("\n");
        sb.append(" FIM DO RELATÓRIO COMPARATIVO\n");
        sb.append("=".repeat(100)).append("\n");
        
        return sb.toString();
    }
    
    /**
     * Gera um gráfico comparativo para uma métrica específica.
     * 
     * @param sb StringBuilder para construir o relatório
     * @param coletores Lista de coletores de estatísticas
     * @param metrica Nome da métrica a ser comparada
     * @param tamanhoMaximo Tamanho máximo das barras
     */
    private static void gerarGraficoComparativo(StringBuilder sb, EstatisticasColetor[] coletores, String metrica, int tamanhoMaximo) {
        // Encontra o valor máximo para escala
        double valorMaximo = 0.0;
        for (EstatisticasColetor coletor : coletores) {
            Map<String, Object> estatisticas = coletor.getEstatisticas();
            Object valor = estatisticas.get(metrica);
            
            if (valor instanceof Double) {
                valorMaximo = Math.max(valorMaximo, (Double) valor);
            } else if (valor instanceof Integer) {
                valorMaximo = Math.max(valorMaximo, (Integer) valor);
            }
        }
        
        // Ajusta para evitar divisão por zero
        valorMaximo = Math.max(valorMaximo, 1.0);
        
        // Gera as barras para cada modelo
        for (EstatisticasColetor coletor : coletores) {
            Map<String, Object> estatisticas = coletor.getEstatisticas();
            String modelo = (String) estatisticas.get("modelo_controle");
            Object valorObj = estatisticas.get(metrica);
            
            double valor = 0.0;
            if (valorObj instanceof Double) {
                valor = (Double) valorObj;
            } else if (valorObj instanceof Integer) {
                valor = (Integer) valorObj;
            }
            
            // Calcula o tamanho da barra (proporcional ao valor)
            int tamanhoBarra = (int) Math.min(tamanhoMaximo, Math.round(tamanhoMaximo * valor / valorMaximo));
            
            // Formata o modelo para ocupar 20 caracteres
            String modeloFormatado = String.format("%-20s", modelo);
            
            // Gera a barra
            sb.append(modeloFormatado).append(" [");
            sb.append("█".repeat(tamanhoBarra));
            sb.append(" ".repeat(tamanhoMaximo - tamanhoBarra));
            sb.append("] ");
            
            if (valorObj instanceof Double) {
                sb.append(String.format("%.2f", valor));
            } else if (valorObj instanceof Integer) {
                sb.append(String.format("%d", (int) valor));
            } else {
                sb.append("N/A");
            }
            
            sb.append("\n");
        }
    }
    
    /**
     * Encontra o melhor modelo para uma métrica específica.
     * 
     * @param coletores Lista de coletores de estatísticas
     * @param metrica Nome da métrica a ser comparada
     * @return Índice do melhor modelo (-1 se não for possível determinar)
     */
    private static int encontrarMelhorModelo(EstatisticasColetor[] coletores, String metrica) {
        int melhorIndice = -1;
        double melhorValor = Double.MAX_VALUE;
        boolean menorEhMelhor = true;
        
        // Para algumas métricas, maior é melhor
        if (metrica.equals("fluxo_total_veiculos")) {
            menorEhMelhor = false;
            melhorValor = Double.MIN_VALUE;
        }
        
        for (int i = 0; i < coletores.length; i++) {
            Map<String, Object> estatisticas = coletores[i].getEstatisticas();
            Object valorObj = estatisticas.get(metrica);
            
            if (valorObj == null) continue;
            
            double valor = 0.0;
            if (valorObj instanceof Double) {
                valor = (Double) valorObj;
            } else if (valorObj instanceof Integer) {
                valor = (Integer) valorObj;
            } else {
                continue;
            }
            
            if (menorEhMelhor) {
                if (valor < melhorValor) {
                    melhorValor = valor;
                    melhorIndice = i;
                }
            } else {
                if (valor > melhorValor) {
                    melhorValor = valor;
                    melhorIndice = i;
                }
            }
        }
        
        return melhorIndice;
    }
    
    /**
     * Encontra o melhor modelo geral considerando todas as métricas.
     * 
     * @param coletores Lista de coletores de estatísticas
     * @param metricas Lista de métricas a serem consideradas
     * @return Índice do melhor modelo geral (-1 se não for possível determinar)
     */
    private static int encontrarMelhorModeloGeral(EstatisticasColetor[] coletores, String[] metricas) {
        if (coletores.length == 0) return -1;
        if (coletores.length == 1) return 0;
        
        int[] pontuacao = new int[coletores.length];
        
        // Para cada métrica, atribui pontos aos modelos (3 para o melhor, 2 para o segundo, 1 para o terceiro)
        for (String metrica : metricas) {
            List<Integer> indices = new ArrayList<>();
            List<Double> valores = new ArrayList<>();
            
            // Coleta os valores para esta métrica
            for (int i = 0; i < coletores.length; i++) {
                Map<String, Object> estatisticas = coletores[i].getEstatisticas();
                Object valorObj = estatisticas.get(metrica);
                
                if (valorObj == null) continue;
                
                double valor = 0.0;
                if (valorObj instanceof Double) {
                    valor = (Double) valorObj;
                } else if (valorObj instanceof Integer) {
                    valor = (Integer) valorObj;
                } else {
                    continue;
                }
                
                indices.add(i);
                valores.add(valor);
            }
            
            // Ordena os índices com base nos valores
            boolean menorEhMelhor = !metrica.equals("fluxo_total_veiculos");
            
            for (int i = 0; i < indices.size(); i++) {
                for (int j = i + 1; j < indices.size(); j++) {
                    boolean trocar = menorEhMelhor 
                            ? valores.get(i) > valores.get(j) 
                            : valores.get(i) < valores.get(j);
                    
                    if (trocar) {
                        // Troca os valores
                        double tempValor = valores.get(i);
                        valores.set(i, valores.get(j));
                        valores.set(j, tempValor);
                        
                        // Troca os índices
                        int tempIndice = indices.get(i);
                        indices.set(i, indices.get(j));
                        indices.set(j, tempIndice);
                    }
                }
            }
            
            // Atribui pontos (3 para o melhor, 2 para o segundo, 1 para o terceiro)
            for (int i = 0; i < Math.min(3, indices.size()); i++) {
                pontuacao[indices.get(i)] += 3 - i;
            }
        }
        
        // Encontra o modelo com maior pontuação
        int melhorIndice = 0;
        int maiorPontuacao = pontuacao[0];
        
        for (int i = 1; i < pontuacao.length; i++) {
            if (pontuacao[i] > maiorPontuacao) {
                maiorPontuacao = pontuacao[i];
                melhorIndice = i;
            }
        }
        
        return melhorIndice;
    }
}
