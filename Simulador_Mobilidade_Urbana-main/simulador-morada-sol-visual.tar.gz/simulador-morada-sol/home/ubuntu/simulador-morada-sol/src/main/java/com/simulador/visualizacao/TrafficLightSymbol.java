
package com.simulador.visualizacao;

/**
 * Classe que representa um símbolo de semáforo no mapa.
 * O semáforo pode estar em um dos três estados: verde, amarelo ou vermelho.
 */
public class TrafficLightSymbol {
    /**
     * Enumeração dos possíveis estados de um semáforo
     */
    public enum State {
        GREEN, YELLOW, RED
    }
    
    private State state;
    
    /**
     * Construtor do símbolo de semáforo
     * 
     * @param state Estado inicial do semáforo
     */
    public TrafficLightSymbol(State state) {
        this.state = state;
    }
    
    /**
     * Renderiza o símbolo do semáforo com a cor apropriada
     * 
     * @return String formatada com o símbolo colorido
     */
    public String render() {
        switch (state) {
            case GREEN:
                return TerminalRenderer.ANSI_GREEN + "●" + TerminalRenderer.ANSI_RESET;
            case YELLOW:
                return TerminalRenderer.ANSI_YELLOW + "●" + TerminalRenderer.ANSI_RESET;
            case RED:
                return TerminalRenderer.ANSI_RED + "●" + TerminalRenderer.ANSI_RESET;
            default:
                return "●";
        }
    }
    
    /**
     * Obtém o estado atual do semáforo
     * 
     * @return Estado atual
     */
    public State getState() {
        return state;
    }
    
    /**
     * Define o estado do semáforo
     * 
     * @param state Novo estado
     */
    public void setState(State state) {
        this.state = state;
    }
}
