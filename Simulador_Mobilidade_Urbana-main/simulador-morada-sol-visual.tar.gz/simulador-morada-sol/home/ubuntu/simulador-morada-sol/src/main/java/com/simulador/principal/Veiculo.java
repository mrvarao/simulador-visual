
package com.simulador.principal;

import java.util.Arrays;
import java.util.Random;

/**
 * Classe que representa um veículo na simulação.
 */
public class Veiculo {
    
    // Identificador único do veículo
    private String id;
    
    // Posição atual do veículo (x, y)
    private int[] posicaoAtual;
    
    // Posição de destino do veículo (x, y)
    private int[] posicaoDestino;
    
    // Estado do veículo
    private boolean ativo;
    private boolean parado;
    
    // Tempo de viagem
    private int tempoViagem;
    
    // Gerador de números aleatórios
    private static final Random random = new Random();
    
    /**
     * Construtor do veículo.
     * 
     * @param id Identificador único do veículo
     * @param posicaoInicial Posição inicial do veículo (x, y)
     * @param posicaoDestino Posição de destino do veículo (x, y)
     */
    public Veiculo(String id, int[] posicaoInicial, int[] posicaoDestino) {
        this.id = id;
        this.posicaoAtual = posicaoInicial;
        this.posicaoDestino = posicaoDestino;
        this.ativo = true;
        this.parado = false;
        this.tempoViagem = 0;
    }
    
    /**
     * Move o veículo em direção ao destino.
     * 
     * @return Nova posição do veículo
     */
    public int[] mover() {
        if (!ativo || parado) {
            return posicaoAtual;
        }
        
        // Incrementa o tempo de viagem
        tempoViagem++;
        
        // Calcula a direção para o destino
        int dx = Integer.compare(posicaoDestino[0], posicaoAtual[0]);
        int dy = Integer.compare(posicaoDestino[1], posicaoAtual[1]);
        
        // Decide se move na horizontal ou vertical
        if (dx != 0 && dy != 0) {
            // Se ambas as direções são possíveis, escolhe aleatoriamente
            if (random.nextBoolean()) {
                posicaoAtual[0] += dx;
            } else {
                posicaoAtual[1] += dy;
            }
        } else if (dx != 0) {
            // Move na horizontal
            posicaoAtual[0] += dx;
        } else if (dy != 0) {
            // Move na vertical
            posicaoAtual[1] += dy;
        }
        
        return posicaoAtual;
    }
    
    /**
     * Verifica se o veículo chegou ao destino.
     * 
     * @return true se o veículo chegou ao destino, false caso contrário
     */
    public boolean chegouAoDestino() {
        return Arrays.equals(posicaoAtual, posicaoDestino);
    }
    
    /**
     * Para o veículo.
     */
    public void parar() {
        parado = true;
    }
    
    /**
     * Faz o veículo partir.
     */
    public void partir() {
        parado = false;
    }
    
    // Getters e Setters
    
    public String getId() {
        return id;
    }
    
    public int[] getPosicaoAtual() {
        return posicaoAtual;
    }
    
    public int[] getPosicaoDestino() {
        return posicaoDestino;
    }
    
    public boolean isAtivo() {
        return ativo;
    }
    
    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
    public boolean isParado() {
        return parado;
    }
    
    public int getTempoViagem() {
        return tempoViagem;
    }
}
