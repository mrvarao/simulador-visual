
package com.simulador.principal;

import com.simulador.estruturas.Grafo;
import com.simulador.visualizacao.TerminalRenderer;
import com.simulador.visualizacao.TrafficLightSymbol;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Classe responsável por criar e gerenciar a estrutura do bairro Morada do Sol.
 * Implementa o mapa específico do bairro com suas ruas, interseções e semáforos.
 */
public class MoradaDoSolFactory {
    
    // Mapa de posições dos semáforos (id -> [x, y])
    private static Map<Integer, int[]> posicoesSemaforos = new HashMap<>();
    
    // Mapa de semáforos por posição ([x,y] -> id)
    private static Map<String, Integer> semaforosPorPosicao = new HashMap<>();
    
    // Mapa de nomes das ruas
    private static Map<Integer, String> nomesRuas = new HashMap<>();
    
    // Mapa de pontos de referência
    private static Map<String, int[]> pontosReferencia = new HashMap<>();
    
    // Gerador de números aleatórios
    private static final Random random = new Random();
    
    /**
     * Cria o grafo que representa o bairro Morada do Sol.
     * 
     * @param grafo Grafo a ser preenchido
     * @param tamanho Tamanho do mapa [largura, altura]
     */
    public static void criarBairro(Grafo grafo, int[] tamanho) {
        int largura = tamanho[0];
        int altura = tamanho[1];
        
        // Limpa os mapas
        posicoesSemaforos.clear();
        semaforosPorPosicao.clear();
        nomesRuas.clear();
        pontosReferencia.clear();
        
        // Define as principais ruas do bairro Morada do Sol
        // Ruas horizontais
        String[] ruasHorizontais = {
            "Avenida Presidente Kennedy",
            "Rua Antônio Ferreira Lopes",
            "Rua Antônio Tapety",
            "Rua Firmino Pires"
        };
        
        // Ruas verticais
        String[] ruasVerticais = {
            "Avenida Duque de Caxias",
            "Rua Coelho Rodrigues",
            "Rua Álvaro Mendes",
            "Rua Senador Teodoro Pacheco"
        };
        
        // Cria os vértices do grafo (interseções)
        int idVertice = 0;
        
        // Cria interseções em uma grade
        for (int x = 5; x < largura; x += 10) {
            for (int y = 5; y < altura; y += 5) {
                // Determina os nomes das ruas que se cruzam nesta interseção
                int indiceHorizontal = (y / 5 - 1) % ruasHorizontais.length;
                int indiceVertical = (x / 10 - 0) % ruasVerticais.length;
                
                String ruaHorizontal = ruasHorizontais[indiceHorizontal];
                String ruaVertical = ruasVerticais[indiceVertical];
                
                String nomeVertice = "Cruzamento " + ruaHorizontal + " com " + ruaVertical;
                grafo.adicionarVertice(idVertice, nomeVertice);
                
                // Adiciona um semáforo nesta interseção
                posicoesSemaforos.put(idVertice, new int[]{x, y});
                semaforosPorPosicao.put(x + "," + y, idVertice);
                
                // Armazena os nomes das ruas
                nomesRuas.put(idVertice, ruaHorizontal + " / " + ruaVertical);
                
                idVertice++;
            }
        }
        
        // Adiciona pontos de referência do bairro Morada do Sol
        pontosReferencia.put("Shopping Morada do Sol", new int[]{15, 10});
        pontosReferencia.put("Praça da Liberdade", new int[]{25, 15});
        pontosReferencia.put("Hospital São Marcos", new int[]{35, 5});
        pontosReferencia.put("Escola Municipal", new int[]{5, 20});
        pontosReferencia.put("Supermercado Pão de Açúcar", new int[]{45, 10});
        
        // Cria as arestas do grafo (ruas)
        for (int i = 0; i < idVertice; i++) {
            int[] posI = posicoesSemaforos.get(i);
            
            for (int j = 0; j < idVertice; j++) {
                if (i == j) continue;
                
                int[] posJ = posicoesSemaforos.get(j);
                
                // Conecta apenas interseções adjacentes (horizontal ou vertical)
                if ((posI[0] == posJ[0] && Math.abs(posI[1] - posJ[1]) <= 5) ||
                    (posI[1] == posJ[1] && Math.abs(posI[0] - posJ[0]) <= 10)) {
                    
                    // Calcula a distância entre as interseções
                    double distancia = Math.sqrt(
                        Math.pow(posI[0] - posJ[0], 2) +
                        Math.pow(posI[1] - posJ[1], 2)
                    );
                    
                    // Determina o nome da rua
                    String nomeRua;
                    if (posI[0] == posJ[0]) {
                        // Rua vertical
                        int indice = (posI[0] / 10) % ruasVerticais.length;
                        nomeRua = ruasVerticais[indice];
                    } else {
                        // Rua horizontal
                        int indice = (posI[1] / 5 - 1) % ruasHorizontais.length;
                        nomeRua = ruasHorizontais[indice];
                    }
                    
                    // Adiciona a aresta ao grafo
                    grafo.adicionarAresta(i, j, distancia, nomeRua);
                }
            }
        }
    }
    
    /**
     * Cria o mapa visual do bairro Morada do Sol no renderizador.
     * 
     * @param renderer Renderizador de terminal
     * @param tamanho Tamanho do mapa [largura, altura]
     */
    public static void criarMapaVisual(TerminalRenderer renderer, int[] tamanho) {
        int largura = tamanho[0];
        int altura = tamanho[1];
        
        // Cria ruas horizontais
        for (int y = 5; y < altura; y += 5) {
            for (int x = 0; x < largura; x++) {
                renderer.setHorizontalRoad(x, y);
            }
        }
        
        // Cria ruas verticais
        for (int x = 5; x < largura; x += 10) {
            for (int y = 0; y < altura; y++) {
                renderer.setVerticalRoad(x, y);
            }
        }
        
        // Cria interseções
        for (int x = 5; x < largura; x += 10) {
            for (int y = 5; y < altura; y += 5) {
                renderer.setCrossroad(x, y);
            }
        }
        
        // Adiciona pontos de referência ao mapa
        for (Map.Entry<String, int[]> entry : pontosReferencia.entrySet()) {
            String nome = entry.getKey();
            int[] pos = entry.getValue();
            
            // Adiciona um marcador para o ponto de referência
            renderer.setMapCell(pos[0], pos[1], 'P');
            
            // Adiciona o nome do ponto de referência ao log
            renderer.log("Ponto de Referência: " + nome + " em (" + pos[0] + "," + pos[1] + ")");
        }
    }
    
    /**
     * Gera uma posição aleatória válida no bairro (em uma rua).
     * 
     * @param tamanho Tamanho do mapa [largura, altura]
     * @return Posição aleatória [x, y]
     */
    public static int[] gerarPosicaoAleatoria(int[] tamanho) {
        int largura = tamanho[0];
        int altura = tamanho[1];
        
        int x, y;
        
        // Decide se a posição será em uma rua horizontal ou vertical
        if (random.nextBoolean()) {
            // Rua horizontal
            y = 5 * (random.nextInt(altura / 5 - 1) + 1);
            x = random.nextInt(largura);
        } else {
            // Rua vertical
            x = 5 + 10 * random.nextInt(largura / 10);
            y = random.nextInt(altura);
        }
        
        return new int[]{x, y};
    }
    
    /**
     * Obtém o mapa de posições dos semáforos.
     * 
     * @return Mapa de posições dos semáforos (id -> [x, y])
     */
    public static Map<Integer, int[]> getPosicoesSemaforos() {
        return posicoesSemaforos;
    }
    
    /**
     * Verifica se há um semáforo em uma determinada posição.
     * 
     * @param posicao Posição a ser verificada [x, y]
     * @return ID do semáforo ou null se não houver semáforo
     */
    public static Integer getSemaforoEmPosicao(int[] posicao) {
        String chave = posicao[0] + "," + posicao[1];
        return semaforosPorPosicao.get(chave);
    }
    
    /**
     * Obtém o nome da rua em uma determinada interseção.
     * 
     * @param idSemaforo ID do semáforo na interseção
     * @return Nome da rua ou "Desconhecida" se não encontrada
     */
    public static String getNomeRua(int idSemaforo) {
        return nomesRuas.getOrDefault(idSemaforo, "Rua Desconhecida");
    }
    
    /**
     * Gera um estado aleatório para um semáforo.
     * 
     * @return Estado aleatório (GREEN, YELLOW, RED)
     */
    public static TrafficLightSymbol.State gerarEstadoAleatorio() {
        int valor = random.nextInt(3);
        switch (valor) {
            case 0:
                return TrafficLightSymbol.State.GREEN;
            case 1:
                return TrafficLightSymbol.State.YELLOW;
            default:
                return TrafficLightSymbol.State.RED;
        }
    }
}
