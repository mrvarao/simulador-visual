
package com.simulador.visualizacao;

/**
 * Classe de demonstração que mostra como utilizar o sistema de visualização.
 * Esta classe pode ser usada como exemplo para integrar o sistema de visualização
 * ao simulador de mobilidade urbana.
 */
public class SimulationVisualizer {
    
    /**
     * Método principal para demonstração
     * 
     * @param args Argumentos da linha de comando
     * @throws InterruptedException Se a thread for interrompida durante o sleep
     */
    public static void main(String[] args) throws InterruptedException {
        // Cria um renderizador de terminal com um mapa 30x15 em um terminal 80x25
        TerminalRenderer renderer = new TerminalRenderer(30, 15, 80, 25);
        
        // Inicia o renderizador
        renderer.start();
        
        // Cria um mapa simples com ruas e cruzamentos
        createSampleMap(renderer);
        
        // Adiciona alguns semáforos
        renderer.addTrafficLight(10, 5, TrafficLightSymbol.State.RED);
        renderer.addTrafficLight(20, 5, TrafficLightSymbol.State.GREEN);
        renderer.addTrafficLight(10, 10, TrafficLightSymbol.State.YELLOW);
        
        // Adiciona alguns veículos
        renderer.addVehicle(5, 5, 'C', TerminalRenderer.ANSI_BLUE);
        renderer.addVehicle(15, 5, 'B', TerminalRenderer.ANSI_RED);
        renderer.addVehicle(25, 10, 'M', TerminalRenderer.ANSI_GREEN);
        
        // Atualiza algumas estatísticas
        renderer.updateStat("Tempo de Simulação", "00:05:30");
        renderer.updateStat("Veículos Ativos", "3");
        renderer.updateStat("Velocidade Média", "40 km/h");
        renderer.updateStat("Congestionamentos", "1");
        
        // Adiciona alguns logs
        renderer.log("Simulação iniciada");
        renderer.log("Veículo C adicionado na posição (5,5)");
        renderer.log("Veículo B adicionado na posição (15,5)");
        renderer.log("Veículo M adicionado na posição (25,10)");
        renderer.log("Semáforo em (10,5) mudou para VERMELHO");
        
        // Renderiza a visualização inicial
        renderer.render();
        
        // Simula algumas atualizações
        for (int i = 0; i < 10; i++) {
            Thread.sleep(1000); // Espera 1 segundo
            
            // Atualiza a posição de um veículo
            renderer.removeVehicle(5 + i, 5);
            renderer.addVehicle(6 + i, 5, 'C', TerminalRenderer.ANSI_BLUE);
            
            // Atualiza o estado de um semáforo
            if (i % 3 == 0) {
                renderer.updateTrafficLight(10, 5, TrafficLightSymbol.State.GREEN);
                renderer.log("Semáforo em (10,5) mudou para VERDE");
            } else if (i % 3 == 1) {
                renderer.updateTrafficLight(10, 5, TrafficLightSymbol.State.YELLOW);
                renderer.log("Semáforo em (10,5) mudou para AMARELO");
            } else {
                renderer.updateTrafficLight(10, 5, TrafficLightSymbol.State.RED);
                renderer.log("Semáforo em (10,5) mudou para VERMELHO");
            }
            
            // Atualiza o tempo de simulação
            renderer.updateStat("Tempo de Simulação", String.format("00:05:%02d", 30 + i));
            
            // Renderiza a visualização atualizada
            renderer.render();
        }
        
        // Para o renderizador
        renderer.stop();
    }
    
    /**
     * Cria um mapa de exemplo com ruas e cruzamentos
     * 
     * @param renderer O renderizador de terminal
     */
    private static void createSampleMap(TerminalRenderer renderer) {
        // Cria uma rua horizontal
        for (int x = 0; x < 30; x++) {
            renderer.setHorizontalRoad(x, 5);
            renderer.setHorizontalRoad(x, 10);
        }
        
        // Cria ruas verticais
        for (int y = 0; y < 15; y++) {
            renderer.setVerticalRoad(10, y);
            renderer.setVerticalRoad(20, y);
        }
        
        // Cria cruzamentos
        renderer.setCrossroad(10, 5);
        renderer.setCrossroad(20, 5);
        renderer.setCrossroad(10, 10);
        renderer.setCrossroad(20, 10);
    }
}
