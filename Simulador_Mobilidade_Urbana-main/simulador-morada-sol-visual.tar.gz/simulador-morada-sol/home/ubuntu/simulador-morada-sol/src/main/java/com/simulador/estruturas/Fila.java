
package com.simulador.estruturas;

/**
 * Implementação de uma fila (FIFO - First In, First Out) para gerenciar elementos em ordem de chegada.
 * Esta estrutura é útil para gerenciar veículos em espera, semáforos, etc.
 * 
 * @param <T> Tipo de dados armazenados na fila
 */
public class Fila<T> {
    
    /**
     * Classe interna que representa um nó na fila
     */
    private class No {
        private T dado;
        private No proximo;
        
        /**
         * Construtor do nó
         * 
         * @param dado Dado a ser armazenado no nó
         */
        public No(T dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }
    
    private No primeiro;
    private No ultimo;
    private int tamanho;
    
    /**
     * Construtor da fila
     */
    public Fila() {
        this.primeiro = null;
        this.ultimo = null;
        this.tamanho = 0;
    }
    
    /**
     * Verifica se a fila está vazia
     * 
     * @return true se a fila estiver vazia, false caso contrário
     */
    public boolean estaVazia() {
        return tamanho == 0;
    }
    
    /**
     * Retorna o tamanho atual da fila
     * 
     * @return Número de elementos na fila
     */
    public int tamanho() {
        return tamanho;
    }
    
    /**
     * Adiciona um elemento ao final da fila (enfileirar)
     * 
     * @param dado Elemento a ser adicionado
     */
    public void enfileirar(T dado) {
        No novoNo = new No(dado);
        
        if (estaVazia()) {
            primeiro = novoNo;
        } else {
            ultimo.proximo = novoNo;
        }
        
        ultimo = novoNo;
        tamanho++;
    }
    
    /**
     * Remove e retorna o elemento do início da fila (desenfileirar)
     * 
     * @return O elemento removido do início da fila
     * @throws IllegalStateException Se a fila estiver vazia
     */
    public T desenfileirar() {
        if (estaVazia()) {
            throw new IllegalStateException("A fila está vazia");
        }
        
        T dado = primeiro.dado;
        primeiro = primeiro.proximo;
        tamanho--;
        
        if (estaVazia()) {
            ultimo = null;
        }
        
        return dado;
    }
    
    /**
     * Retorna o elemento do início da fila sem removê-lo
     * 
     * @return O elemento do início da fila
     * @throws IllegalStateException Se a fila estiver vazia
     */
    public T primeiro() {
        if (estaVazia()) {
            throw new IllegalStateException("A fila está vazia");
        }
        
        return primeiro.dado;
    }
    
    /**
     * Limpa a fila, removendo todos os elementos
     */
    public void limpar() {
        primeiro = null;
        ultimo = null;
        tamanho = 0;
    }
    
    /**
     * Verifica se um elemento está presente na fila
     * 
     * @param dado Elemento a ser verificado
     * @return true se o elemento estiver na fila, false caso contrário
     */
    public boolean contem(T dado) {
        No atual = primeiro;
        
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                return true;
            }
            atual = atual.proximo;
        }
        
        return false;
    }
}
