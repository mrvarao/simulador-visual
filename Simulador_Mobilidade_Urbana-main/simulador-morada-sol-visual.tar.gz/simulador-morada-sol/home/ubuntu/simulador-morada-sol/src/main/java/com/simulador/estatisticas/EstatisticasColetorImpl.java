
package com.simulador.estatisticas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implementação concreta do coletor de estatísticas.
 * Coleta e armazena dados estatísticos durante a simulação.
 */
public class EstatisticasColetorImpl implements EstatisticasColetor {
    
    // Modelo de controle de semáforos associado a este coletor
    private String modeloControle;
    
    // Estatísticas de viagens
    private Map<String, ViagemInfo> viagensAtivas;
    private List<ViagemInfo> viagensCompletas;
    
    // Estatísticas de semáforos
    private Map<Integer, SemaforoInfo> infoSemaforos;
    
    // Estatísticas de fluxo de veículos
    private Map<String, List<FluxoInfo>> fluxoVeiculos;
    
    // Estatísticas de congestionamento
    private Map<String, List<CongestionamentoInfo>> congestionamentos;
    
    // Tempo total da simulação
    private int tempoTotalSimulacao;
    
    // Gerador de relatórios
    private RelatorioGerador relatorioGerador;
    
    /**
     * Construtor do coletor de estatísticas.
     * 
     * @param modeloControle Nome do modelo de controle de semáforos
     */
    public EstatisticasColetorImpl(String modeloControle) {
        this.modeloControle = modeloControle;
        this.viagensAtivas = new ConcurrentHashMap<>();
        this.viagensCompletas = new ArrayList<>();
        this.infoSemaforos = new ConcurrentHashMap<>();
        this.fluxoVeiculos = new ConcurrentHashMap<>();
        this.congestionamentos = new ConcurrentHashMap<>();
        this.tempoTotalSimulacao = 0;
        this.relatorioGerador = new RelatorioGerador();
    }
    
    @Override
    public void inicializar() {
        limpar();
    }
    
    @Override
    public void registrarInicioViagem(String idVeiculo, int[] origem, int[] destino, int tempoSimulacao) {
        ViagemInfo viagem = new ViagemInfo(idVeiculo, origem, destino, tempoSimulacao);
        viagensAtivas.put(idVeiculo, viagem);
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public void registrarFimViagem(String idVeiculo, int tempoSimulacao) {
        ViagemInfo viagem = viagensAtivas.remove(idVeiculo);
        if (viagem != null) {
            viagem.setTempoFim(tempoSimulacao);
            viagensCompletas.add(viagem);
            tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
        }
    }
    
    @Override
    public void registrarParadaSemaforo(String idVeiculo, int idSemaforo, int tempoSimulacao) {
        ViagemInfo viagem = viagensAtivas.get(idVeiculo);
        if (viagem != null) {
            viagem.registrarParadaSemaforo(idSemaforo, tempoSimulacao);
        }
        
        SemaforoInfo semaforo = infoSemaforos.computeIfAbsent(idSemaforo, k -> new SemaforoInfo(idSemaforo));
        semaforo.incrementarVeiculosParados();
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public void registrarPartidaSemaforo(String idVeiculo, int idSemaforo, int tempoSimulacao) {
        ViagemInfo viagem = viagensAtivas.get(idVeiculo);
        if (viagem != null) {
            viagem.registrarPartidaSemaforo(idSemaforo, tempoSimulacao);
        }
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public void registrarMudancaEstadoSemaforo(int idSemaforo, String estadoAnterior, String novoEstado, int tempoSimulacao) {
        SemaforoInfo semaforo = infoSemaforos.computeIfAbsent(idSemaforo, k -> new SemaforoInfo(idSemaforo));
        semaforo.registrarMudancaEstado(estadoAnterior, novoEstado, tempoSimulacao);
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public void registrarFluxoVeiculos(int[] coordenadas, int fluxo, int tempoSimulacao) {
        String chave = coordenadas[0] + "," + coordenadas[1];
        List<FluxoInfo> fluxos = fluxoVeiculos.computeIfAbsent(chave, k -> new ArrayList<>());
        fluxos.add(new FluxoInfo(coordenadas, fluxo, tempoSimulacao));
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public void registrarConsumoEnergetico(int idSemaforo, double consumo, int tempoSimulacao) {
        SemaforoInfo semaforo = infoSemaforos.computeIfAbsent(idSemaforo, k -> new SemaforoInfo(idSemaforo));
        semaforo.registrarConsumoEnergetico(consumo);
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public void registrarCongestionamento(int[] coordenadas, int nivel, int tempoSimulacao) {
        String chave = coordenadas[0] + "," + coordenadas[1];
        List<CongestionamentoInfo> niveis = congestionamentos.computeIfAbsent(chave, k -> new ArrayList<>());
        niveis.add(new CongestionamentoInfo(coordenadas, nivel, tempoSimulacao));
        tempoTotalSimulacao = Math.max(tempoTotalSimulacao, tempoSimulacao);
    }
    
    @Override
    public Map<String, Object> getEstatisticas() {
        Map<String, Object> estatisticas = new HashMap<>();
        
        // Estatísticas de viagens
        estatisticas.put("modelo_controle", modeloControle);
        estatisticas.put("tempo_total_simulacao", tempoTotalSimulacao);
        estatisticas.put("total_viagens_completas", viagensCompletas.size());
        estatisticas.put("total_viagens_ativas", viagensAtivas.size());
        
        // Tempo médio de viagem
        double tempoMedioViagem = viagensCompletas.stream()
                .mapToInt(ViagemInfo::getDuracaoViagem)
                .average()
                .orElse(0.0);
        estatisticas.put("tempo_medio_viagem", tempoMedioViagem);
        
        // Tempo médio de espera em semáforos
        double tempoMedioEsperaSemaforos = viagensCompletas.stream()
                .mapToDouble(ViagemInfo::getTempoTotalEsperaSemaforos)
                .average()
                .orElse(0.0);
        estatisticas.put("tempo_medio_espera_semaforos", tempoMedioEsperaSemaforos);
        
        // Percentual de tempo em espera
        double percentualTempoEspera = (tempoMedioViagem > 0) 
                ? (tempoMedioEsperaSemaforos / tempoMedioViagem) * 100 
                : 0.0;
        estatisticas.put("percentual_tempo_espera", percentualTempoEspera);
        
        // Consumo energético total dos semáforos
        double consumoEnergeticoTotal = infoSemaforos.values().stream()
                .mapToDouble(SemaforoInfo::getConsumoEnergeticoTotal)
                .sum();
        estatisticas.put("consumo_energetico_total", consumoEnergeticoTotal);
        
        // Consumo energético médio por semáforo
        double consumoEnergeticoMedio = infoSemaforos.values().stream()
                .mapToDouble(SemaforoInfo::getConsumoEnergeticoTotal)
                .average()
                .orElse(0.0);
        estatisticas.put("consumo_energetico_medio", consumoEnergeticoMedio);
        
        // Nível médio de congestionamento
        double nivelMedioCongestionamento = congestionamentos.values().stream()
                .flatMap(List::stream)
                .mapToInt(CongestionamentoInfo::getNivel)
                .average()
                .orElse(0.0);
        estatisticas.put("nivel_medio_congestionamento", nivelMedioCongestionamento);
        
        // Fluxo total de veículos
        int fluxoTotal = fluxoVeiculos.values().stream()
                .flatMap(List::stream)
                .mapToInt(FluxoInfo::getFluxo)
                .sum();
        estatisticas.put("fluxo_total_veiculos", fluxoTotal);
        
        return estatisticas;
    }
    
    @Override
    public String gerarRelatorio() {
        return relatorioGerador.gerarRelatorio(this);
    }
    
    @Override
    public void limpar() {
        viagensAtivas.clear();
        viagensCompletas.clear();
        infoSemaforos.clear();
        fluxoVeiculos.clear();
        congestionamentos.clear();
        tempoTotalSimulacao = 0;
    }
    
    /**
     * Obtém o modelo de controle de semáforos.
     * 
     * @return Nome do modelo de controle
     */
    public String getModeloControle() {
        return modeloControle;
    }
    
    /**
     * Obtém a lista de viagens completas.
     * 
     * @return Lista de viagens completas
     */
    public List<ViagemInfo> getViagensCompletas() {
        return new ArrayList<>(viagensCompletas);
    }
    
    /**
     * Obtém o mapa de informações de semáforos.
     * 
     * @return Mapa de informações de semáforos
     */
    public Map<Integer, SemaforoInfo> getInfoSemaforos() {
        return new HashMap<>(infoSemaforos);
    }
    
    /**
     * Obtém o mapa de fluxo de veículos.
     * 
     * @return Mapa de fluxo de veículos
     */
    public Map<String, List<FluxoInfo>> getFluxoVeiculos() {
        return new HashMap<>(fluxoVeiculos);
    }
    
    /**
     * Obtém o mapa de congestionamentos.
     * 
     * @return Mapa de congestionamentos
     */
    public Map<String, List<CongestionamentoInfo>> getCongestionamentos() {
        return new HashMap<>(congestionamentos);
    }
    
    /**
     * Obtém o tempo total da simulação.
     * 
     * @return Tempo total da simulação em segundos
     */
    public int getTempoTotalSimulacao() {
        return tempoTotalSimulacao;
    }
    
    /**
     * Classe interna que representa informações de uma viagem.
     */
    public static class ViagemInfo {
        private String idVeiculo;
        private int[] origem;
        private int[] destino;
        private int tempoInicio;
        private int tempoFim;
        private Map<Integer, List<ParadaSemaforoInfo>> paradasSemaforo;
        
        public ViagemInfo(String idVeiculo, int[] origem, int[] destino, int tempoInicio) {
            this.idVeiculo = idVeiculo;
            this.origem = origem;
            this.destino = destino;
            this.tempoInicio = tempoInicio;
            this.tempoFim = -1;
            this.paradasSemaforo = new HashMap<>();
        }
        
        public void registrarParadaSemaforo(int idSemaforo, int tempo) {
            List<ParadaSemaforoInfo> paradas = paradasSemaforo.computeIfAbsent(idSemaforo, k -> new ArrayList<>());
            paradas.add(new ParadaSemaforoInfo(tempo, -1));
        }
        
        public void registrarPartidaSemaforo(int idSemaforo, int tempo) {
            List<ParadaSemaforoInfo> paradas = paradasSemaforo.get(idSemaforo);
            if (paradas != null && !paradas.isEmpty()) {
                ParadaSemaforoInfo ultimaParada = paradas.get(paradas.size() - 1);
                if (ultimaParada.getTempoFim() == -1) {
                    ultimaParada.setTempoFim(tempo);
                }
            }
        }
        
        public int getDuracaoViagem() {
            return (tempoFim != -1) ? (tempoFim - tempoInicio) : -1;
        }
        
        public double getTempoTotalEsperaSemaforos() {
            return paradasSemaforo.values().stream()
                    .flatMap(List::stream)
                    .filter(p -> p.getTempoFim() != -1)
                    .mapToInt(p -> p.getTempoFim() - p.getTempoInicio())
                    .sum();
        }
        
        public void setTempoFim(int tempoFim) {
            this.tempoFim = tempoFim;
        }
        
        public String getIdVeiculo() {
            return idVeiculo;
        }
        
        public int[] getOrigem() {
            return origem;
        }
        
        public int[] getDestino() {
            return destino;
        }
        
        public int getTempoInicio() {
            return tempoInicio;
        }
        
        public int getTempoFim() {
            return tempoFim;
        }
        
        public Map<Integer, List<ParadaSemaforoInfo>> getParadasSemaforo() {
            return new HashMap<>(paradasSemaforo);
        }
    }
    
    /**
     * Classe interna que representa informações de uma parada em semáforo.
     */
    public static class ParadaSemaforoInfo {
        private int tempoInicio;
        private int tempoFim;
        
        public ParadaSemaforoInfo(int tempoInicio, int tempoFim) {
            this.tempoInicio = tempoInicio;
            this.tempoFim = tempoFim;
        }
        
        public int getTempoInicio() {
            return tempoInicio;
        }
        
        public int getTempoFim() {
            return tempoFim;
        }
        
        public void setTempoFim(int tempoFim) {
            this.tempoFim = tempoFim;
        }
    }
    
    /**
     * Classe interna que representa informações de um semáforo.
     */
    public static class SemaforoInfo {
        private int idSemaforo;
        private int veiculosParados;
        private double consumoEnergeticoTotal;
        private List<MudancaEstadoInfo> mudancasEstado;
        
        public SemaforoInfo(int idSemaforo) {
            this.idSemaforo = idSemaforo;
            this.veiculosParados = 0;
            this.consumoEnergeticoTotal = 0.0;
            this.mudancasEstado = new ArrayList<>();
        }
        
        public void incrementarVeiculosParados() {
            veiculosParados++;
        }
        
        public void registrarConsumoEnergetico(double consumo) {
            consumoEnergeticoTotal += consumo;
        }
        
        public void registrarMudancaEstado(String estadoAnterior, String novoEstado, int tempo) {
            mudancasEstado.add(new MudancaEstadoInfo(estadoAnterior, novoEstado, tempo));
        }
        
        public int getIdSemaforo() {
            return idSemaforo;
        }
        
        public int getVeiculosParados() {
            return veiculosParados;
        }
        
        public double getConsumoEnergeticoTotal() {
            return consumoEnergeticoTotal;
        }
        
        public List<MudancaEstadoInfo> getMudancasEstado() {
            return new ArrayList<>(mudancasEstado);
        }
    }
    
    /**
     * Classe interna que representa informações de mudança de estado de um semáforo.
     */
    public static class MudancaEstadoInfo {
        private String estadoAnterior;
        private String novoEstado;
        private int tempo;
        
        public MudancaEstadoInfo(String estadoAnterior, String novoEstado, int tempo) {
            this.estadoAnterior = estadoAnterior;
            this.novoEstado = novoEstado;
            this.tempo = tempo;
        }
        
        public String getEstadoAnterior() {
            return estadoAnterior;
        }
        
        public String getNovoEstado() {
            return novoEstado;
        }
        
        public int getTempo() {
            return tempo;
        }
    }
    
    /**
     * Classe interna que representa informações de fluxo de veículos.
     */
    public static class FluxoInfo {
        private int[] coordenadas;
        private int fluxo;
        private int tempo;
        
        public FluxoInfo(int[] coordenadas, int fluxo, int tempo) {
            this.coordenadas = coordenadas;
            this.fluxo = fluxo;
            this.tempo = tempo;
        }
        
        public int[] getCoordenadas() {
            return coordenadas;
        }
        
        public int getFluxo() {
            return fluxo;
        }
        
        public int getTempo() {
            return tempo;
        }
    }
    
    /**
     * Classe interna que representa informações de congestionamento.
     */
    public static class CongestionamentoInfo {
        private int[] coordenadas;
        private int nivel;
        private int tempo;
        
        public CongestionamentoInfo(int[] coordenadas, int nivel, int tempo) {
            this.coordenadas = coordenadas;
            this.nivel = nivel;
            this.tempo = tempo;
        }
        
        public int[] getCoordenadas() {
            return coordenadas;
        }
        
        public int getNivel() {
            return nivel;
        }
        
        public int getTempo() {
            return tempo;
        }
    }
}
