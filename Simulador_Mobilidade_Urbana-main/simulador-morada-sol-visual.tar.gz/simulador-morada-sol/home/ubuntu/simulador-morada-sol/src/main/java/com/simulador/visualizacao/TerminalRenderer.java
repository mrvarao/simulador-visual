
package com.simulador.visualizacao;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe principal responsável por gerenciar a renderização no terminal.
 * Coordena os diferentes componentes visuais e atualiza a tela.
 */
public class TerminalRenderer {
    // Códigos ANSI para cores e formatação
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    
    // Códigos ANSI para cores de fundo
    public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
    public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";
    
    // Códigos ANSI para controle do cursor e tela
    public static final String ANSI_CLEAR_SCREEN = "\u001B[2J";
    public static final String ANSI_HOME = "\u001B[H";
    public static final String ANSI_HIDE_CURSOR = "\u001B[?25l";
    public static final String ANSI_SHOW_CURSOR = "\u001B[?25h";
    
    private CityMapCanvas mapCanvas;
    private StatsPanel statsPanel;
    private LogPanel logPanel;
    private int terminalWidth;
    private int terminalHeight;
    private boolean isRunning;
    
    /**
     * Construtor do renderizador de terminal
     * 
     * @param mapWidth Largura do mapa da cidade
     * @param mapHeight Altura do mapa da cidade
     * @param terminalWidth Largura do terminal
     * @param terminalHeight Altura do terminal
     */
    public TerminalRenderer(int mapWidth, int mapHeight, int terminalWidth, int terminalHeight) {
        this.terminalWidth = terminalWidth;
        this.terminalHeight = terminalHeight;
        this.mapCanvas = new CityMapCanvas(mapWidth, mapHeight);
        
        // Calcula o espaço disponível para os painéis
        int statsPanelHeight = 5;
        int logPanelHeight = terminalHeight - mapHeight - statsPanelHeight - 2;
        
        this.statsPanel = new StatsPanel(terminalWidth, statsPanelHeight);
        this.logPanel = new LogPanel(terminalWidth, logPanelHeight);
        this.isRunning = false;
    }
    
    /**
     * Inicia o renderizador
     */
    public void start() {
        isRunning = true;
        // Esconde o cursor e limpa a tela
        System.out.print(ANSI_HIDE_CURSOR);
        clearScreen();
    }
    
    /**
     * Para o renderizador
     */
    public void stop() {
        isRunning = false;
        // Mostra o cursor novamente
        System.out.print(ANSI_SHOW_CURSOR);
    }
    
    /**
     * Limpa a tela do terminal
     */
    public void clearScreen() {
        System.out.print(ANSI_CLEAR_SCREEN + ANSI_HOME);
    }
    
    /**
     * Atualiza a visualização no terminal
     */
    public void render() {
        if (!isRunning) return;
        
        clearScreen();
        
        // Renderiza o mapa
        String mapRendering = mapCanvas.render();
        System.out.println(mapRendering);
        
        // Renderiza o painel de estatísticas
        String statsRendering = statsPanel.render();
        System.out.println(statsRendering);
        
        // Renderiza o painel de logs
        String logRendering = logPanel.render();
        System.out.println(logRendering);
        
        // Força a saída imediata
        System.out.flush();
    }
    
    /**
     * Posiciona o cursor em uma posição específica do terminal
     * 
     * @param row Linha (y)
     * @param col Coluna (x)
     */
    public void setCursorPosition(int row, int col) {
        System.out.print("\u001B[" + row + ";" + col + "H");
    }
    
    /**
     * Obtém o canvas do mapa da cidade
     * 
     * @return O canvas do mapa
     */
    public CityMapCanvas getMapCanvas() {
        return mapCanvas;
    }
    
    /**
     * Obtém o painel de estatísticas
     * 
     * @return O painel de estatísticas
     */
    public StatsPanel getStatsPanel() {
        return statsPanel;
    }
    
    /**
     * Obtém o painel de logs
     * 
     * @return O painel de logs
     */
    public LogPanel getLogPanel() {
        return logPanel;
    }
    
    /**
     * Adiciona uma mensagem ao painel de logs
     * 
     * @param message Mensagem a ser adicionada
     */
    public void log(String message) {
        logPanel.addLog(message);
    }
    
    /**
     * Atualiza uma estatística no painel de estatísticas
     * 
     * @param key Chave da estatística
     * @param value Valor da estatística
     */
    public void updateStat(String key, String value) {
        statsPanel.updateStat(key, value);
    }
    
    /**
     * Adiciona um veículo ao mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param symbol Símbolo do veículo
     * @param color Cor do veículo
     */
    public void addVehicle(int x, int y, char symbol, String color) {
        mapCanvas.addVehicle(x, y, new VehicleSymbol(symbol, color));
    }
    
    /**
     * Remove um veículo do mapa
     * 
     * @param x Posição x
     * @param y Posição y
     */
    public void removeVehicle(int x, int y) {
        mapCanvas.removeVehicle(x, y);
    }
    
    /**
     * Adiciona um semáforo ao mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param state Estado do semáforo (GREEN, YELLOW, RED)
     */
    public void addTrafficLight(int x, int y, TrafficLightSymbol.State state) {
        mapCanvas.addTrafficLight(x, y, new TrafficLightSymbol(state));
    }
    
    /**
     * Atualiza o estado de um semáforo no mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param state Novo estado do semáforo
     */
    public void updateTrafficLight(int x, int y, TrafficLightSymbol.State state) {
        mapCanvas.updateTrafficLight(x, y, state);
    }
    
    /**
     * Define uma célula do mapa como rua horizontal
     * 
     * @param x Posição x
     * @param y Posição y
     */
    public void setHorizontalRoad(int x, int y) {
        mapCanvas.setCell(x, y, CityMapCanvas.HORIZONTAL_ROAD);
    }
    
    /**
     * Define uma célula do mapa como rua vertical
     * 
     * @param x Posição x
     * @param y Posição y
     */
    public void setVerticalRoad(int x, int y) {
        mapCanvas.setCell(x, y, CityMapCanvas.VERTICAL_ROAD);
    }
    
    /**
     * Define uma célula do mapa como cruzamento
     * 
     * @param x Posição x
     * @param y Posição y
     */
    public void setCrossroad(int x, int y) {
        mapCanvas.setCell(x, y, CityMapCanvas.CROSSROAD);
    }
    
    /**
     * Define uma célula do mapa como um tipo específico
     * 
     * @param x Posição x
     * @param y Posição y
     * @param cellType Tipo de célula
     */
    public void setMapCell(int x, int y, char cellType) {
        mapCanvas.setCell(x, y, cellType);
    }
}
