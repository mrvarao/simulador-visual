
package com.simulador.estatisticas;

import java.util.List;

/**
 * Classe utilitária para geração de gráficos em ASCII/Unicode.
 */
public class GraficoASCII {
    
    /**
     * Gera um gráfico de barra horizontal.
     * 
     * @param rotulo Rótulo do gráfico
     * @param valor Valor a ser representado
     * @param tamanhoMaximo Tamanho máximo da barra
     * @return Gráfico formatado
     */
    public static String gerarBarraHorizontal(String rotulo, double valor, int tamanhoMaximo) {
        StringBuilder sb = new StringBuilder();
        
        // Formata o rótulo para ocupar 20 caracteres
        String rotuloFormatado = String.format("%-20s", rotulo);
        
        // Calcula o tamanho da barra (proporcional ao valor)
        int tamanhoBarra = (int) Math.min(tamanhoMaximo, Math.round(valor));
        
        // Gera a barra
        sb.append(rotuloFormatado).append(" [");
        sb.append("█".repeat(tamanhoBarra));
        sb.append(" ".repeat(tamanhoMaximo - tamanhoBarra));
        sb.append("] ").append(String.format("%.2f", valor)).append("\n");
        
        return sb.toString();
    }
    
    /**
     * Gera um gráfico de barras verticais.
     * 
     * @param titulo Título do gráfico
     * @param valores Lista de valores a serem representados
     * @param rotulos Lista de rótulos para o eixo X
     * @param altura Altura do gráfico
     * @return Gráfico formatado
     */
    public static String gerarBarrasVerticais(String titulo, List<Double> valores, List<String> rotulos, int altura) {
        StringBuilder sb = new StringBuilder();
        
        // Título do gráfico
        sb.append(titulo).append("\n");
        sb.append("-".repeat(valores.size() * 4 + 10)).append("\n");
        
        // Encontra o valor máximo para escala
        double valorMaximo = valores.stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        valorMaximo = Math.ceil(valorMaximo * 1.1); // Adiciona 10% para margem
        
        // Gera o gráfico
        for (int y = altura; y > 0; y--) {
            double limiteAtual = valorMaximo * y / altura;
            
            // Eixo Y
            sb.append(String.format("%6.1f |", limiteAtual));
            
            // Barras
            for (Double valor : valores) {
                double alturaRelativa = valor / valorMaximo * altura;
                
                if (alturaRelativa >= y) {
                    sb.append(" █ ");
                } else {
                    sb.append("   ");
                }
            }
            
            sb.append("\n");
        }
        
        // Eixo X
        sb.append("       ");
        sb.append("-".repeat(valores.size() * 3)).append("\n");
        
        // Rótulos do eixo X
        sb.append("       ");
        for (int i = 0; i < rotulos.size(); i++) {
            sb.append(String.format("%-3s", rotulos.get(i).substring(0, Math.min(3, rotulos.get(i).length()))));
        }
        sb.append("\n");
        
        return sb.toString();
    }
    
    /**
     * Gera um gráfico de linha.
     * 
     * @param titulo Título do gráfico
     * @param valores Lista de valores a serem representados
     * @param rotulos Lista de rótulos para o eixo X
     * @param altura Altura do gráfico
     * @param largura Largura do gráfico
     * @return Gráfico formatado
     */
    public static String gerarLinha(String titulo, List<Double> valores, List<String> rotulos, int altura, int largura) {
        StringBuilder sb = new StringBuilder();
        
        // Título do gráfico
        sb.append(titulo).append("\n");
        sb.append("-".repeat(largura)).append("\n");
        
        // Encontra o valor máximo para escala
        double valorMaximo = valores.stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        valorMaximo = Math.ceil(valorMaximo * 1.1); // Adiciona 10% para margem
        
        // Caracteres para desenhar a linha
        char[] simbolos = {'·', '·', '·', '·', '·', '·', '·', '·', '·', '·'};
        
        // Gera o gráfico
        for (int y = altura - 1; y >= 0; y--) {
            double limiteAtual = valorMaximo * (y + 1) / altura;
            
            // Eixo Y
            sb.append(String.format("%6.1f |", limiteAtual));
            
            // Pontos do gráfico
            for (int x = 0; x < Math.min(valores.size(), largura - 8); x++) {
                double valor = valores.get(x);
                double limiteSuperior = valorMaximo * (y + 1) / altura;
                double limiteInferior = valorMaximo * y / altura;
                
                if (x > 0 && x < valores.size()) {
                    double valorAnterior = valores.get(x - 1);
                    
                    // Verifica se a linha cruza esta posição
                    boolean cruzaAtual = (valor >= limiteInferior && valor <= limiteSuperior) ||
                                         (valorAnterior >= limiteInferior && valorAnterior <= limiteSuperior) ||
                                         (valor >= limiteSuperior && valorAnterior <= limiteInferior) ||
                                         (valor <= limiteInferior && valorAnterior >= limiteSuperior);
                    
                    if (cruzaAtual) {
                        if (valor > valorAnterior) {
                            sb.append("/");
                        } else if (valor < valorAnterior) {
                            sb.append("\\");
                        } else {
                            sb.append("-");
                        }
                    } else {
                        sb.append(" ");
                    }
                } else {
                    // Primeiro ponto
                    if (valor >= limiteInferior && valor <= limiteSuperior) {
                        sb.append("o");
                    } else {
                        sb.append(" ");
                    }
                }
            }
            
            sb.append("\n");
        }
        
        // Eixo X
        sb.append("       ");
        sb.append("-".repeat(Math.min(valores.size(), largura - 8))).append("\n");
        
        // Rótulos do eixo X
        sb.append("       ");
        for (int i = 0; i < Math.min(rotulos.size(), largura - 8); i++) {
            if (i % 5 == 0 && i < rotulos.size()) {
                sb.append(rotulos.get(i).charAt(0));
            } else {
                sb.append(" ");
            }
        }
        sb.append("\n");
        
        return sb.toString();
    }
    
    /**
     * Gera um histograma.
     * 
     * @param titulo Título do histograma
     * @param valores Lista de valores a serem representados
     * @param numBins Número de bins (intervalos)
     * @param altura Altura do histograma
     * @return Histograma formatado
     */
    public static String gerarHistograma(String titulo, List<Double> valores, int numBins, int altura) {
        StringBuilder sb = new StringBuilder();
        
        // Título do histograma
        sb.append(titulo).append("\n");
        sb.append("-".repeat(numBins * 3 + 10)).append("\n");
        
        // Encontra o valor mínimo e máximo
        double valorMinimo = valores.stream().mapToDouble(Double::doubleValue).min().orElse(0.0);
        double valorMaximo = valores.stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        
        // Calcula o tamanho de cada bin
        double tamanhoBin = (valorMaximo - valorMinimo) / numBins;
        
        // Conta a frequência em cada bin
        int[] frequencias = new int[numBins];
        for (Double valor : valores) {
            int bin = (int) Math.min(numBins - 1, Math.floor((valor - valorMinimo) / tamanhoBin));
            frequencias[bin]++;
        }
        
        // Encontra a frequência máxima
        int frequenciaMaxima = 0;
        for (int frequencia : frequencias) {
            frequenciaMaxima = Math.max(frequenciaMaxima, frequencia);
        }
        
        // Gera o histograma
        for (int y = altura; y > 0; y--) {
            double limiteAtual = (double) frequenciaMaxima * y / altura;
            
            // Eixo Y
            sb.append(String.format("%3d |", (int) limiteAtual));
            
            // Barras
            for (int frequencia : frequencias) {
                double alturaRelativa = (double) frequencia / frequenciaMaxima * altura;
                
                if (alturaRelativa >= y) {
                    sb.append(" █ ");
                } else {
                    sb.append("   ");
                }
            }
            
            sb.append("\n");
        }
        
        // Eixo X
        sb.append("    ");
        sb.append("-".repeat(numBins * 3 + 2)).append("\n");
        
        // Rótulos do eixo X
        sb.append("    ");
        for (int i = 0; i <= numBins; i++) {
            double valor = valorMinimo + i * tamanhoBin;
            if (i % 2 == 0) {
                sb.append(String.format("%3.1f", valor));
            } else {
                sb.append("   ");
            }
        }
        sb.append("\n");
        
        return sb.toString();
    }
}
