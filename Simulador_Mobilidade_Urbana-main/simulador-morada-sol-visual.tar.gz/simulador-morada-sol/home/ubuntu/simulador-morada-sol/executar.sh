
#!/bin/bash

echo "====================================================="
echo "  SIMULADOR DE MOBILIDADE URBANA - MORADA DO SOL"
echo "====================================================="
echo

# Verifica se o JDK está instalado
if ! command -v javac &> /dev/null; then
    echo "Erro: JDK não encontrado. Por favor, instale o JDK."
    exit 1
fi

echo "Compilando o simulador..."
# Cria o diretório de saída para os arquivos compilados
mkdir -p bin

# Compila todos os arquivos Java
javac -d bin -cp bin $(find src -name "*.java")

# Verifica se a compilação foi bem-sucedida
if [ $? -ne 0 ]; then
    echo "Erro durante a compilação. Verifique os erros acima."
    exit 1
fi

echo "Compilação concluída com sucesso!"
echo

echo "Executando o simulador..."
echo "====================================================="
# Executa a classe principal
java -cp bin com.simulador.principal.SimuladorMain

echo
echo "Simulação finalizada."
echo "====================================================="
