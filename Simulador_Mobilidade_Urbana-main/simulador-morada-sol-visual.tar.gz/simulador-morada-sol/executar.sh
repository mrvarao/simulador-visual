#!/bin/bash
cd home/ubuntu/simulador-morada-sol/
mkdir -p target/classes
find src -name "*.java" > sources.txt
javac -d target/classes @sources.txt
java -cp target/classes com.simulador.principal.SimuladorMain
