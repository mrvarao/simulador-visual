# Sistema de Estatísticas para o Simulador de Mobilidade Urbana

Este pacote contém um sistema completo para coleta de estatísticas e geração de relatórios para o simulador de mobilidade urbana. O sistema permite analisar o desempenho dos diferentes modelos de controle de semáforos e entender o impacto de diferentes estratégias de gerenciamento de tráfego.

## Funcionalidades

O sistema de estatísticas oferece as seguintes funcionalidades:

1. **Coleta de dados**:
   - Tempo médio de viagem dos veículos
   - Tempo médio de espera em semáforos
   - Fluxo de veículos em diferentes partes da cidade
   - Índices de congestionamento
   - Consumo energético dos semáforos

2. **Geração de relatórios**:
   - Relatórios detalhados para cada modelo de controle
   - Gráficos ASCII/Unicode para visualização das estatísticas
   - Relatórios comparativos entre diferentes modelos

3. **Visualização de dados**:
   - Gráficos de barras horizontais e verticais
   - Gráficos de linha
   - Histogramas

## Estrutura do Pacote

- `EstatisticasColetor.java`: Interface que define o comportamento básico de um coletor de estatísticas.
- `EstatisticasColetorImpl.java`: Implementação concreta do coletor de estatísticas.
- `RelatorioGerador.java`: Classe responsável por gerar relatórios a partir das estatísticas coletadas.
- `RelatorioComparativo.java`: Classe responsável por gerar relatórios comparativos entre diferentes modelos.
- `GraficoASCII.java`: Classe utilitária para geração de gráficos em ASCII/Unicode.
- `EstatisticasDemo.java`: Classe de demonstração para testar o sistema de estatísticas.

## Como Usar

### 1. Criar um coletor de estatísticas

```java
// Cria um coletor para o modelo de controle "Ciclo Fixo"
EstatisticasColetor coletor = new EstatisticasColetorImpl("Ciclo Fixo");
coletor.inicializar();
```

### 2. Registrar eventos durante a simulação

```java
// Registra o início de uma viagem
coletor.registrarInicioViagem("V1", new int[]{0, 0}, new int[]{10, 10}, 0);

// Registra uma parada em um semáforo
coletor.registrarParadaSemaforo("V1", 1, 10);

// Registra a partida de um semáforo
coletor.registrarPartidaSemaforo("V1", 1, 15);

// Registra o fim de uma viagem
coletor.registrarFimViagem("V1", 30);

// Registra o consumo energético de um semáforo
coletor.registrarConsumoEnergetico(1, 5.0, 20);

// Registra o fluxo de veículos em um ponto
coletor.registrarFluxoVeiculos(new int[]{5, 5}, 10, 20);

// Registra o nível de congestionamento em um ponto
coletor.registrarCongestionamento(new int[]{5, 5}, 50, 20);
```

### 3. Gerar relatórios

```java
// Gera um relatório detalhado
String relatorio = coletor.gerarRelatorio();
System.out.println(relatorio);

// Gera um relatório comparativo entre diferentes modelos
EstatisticasColetor[] coletores = {coletorCicloFixo, coletorTempoEspera, coletorEnergia};
String relatorioComparativo = EstatisticasColetor.gerarRelatorioComparativo(coletores);
System.out.println(relatorioComparativo);
```

### 4. Integração com o simulador

Para integrar o sistema de estatísticas ao simulador, é necessário:

1. Criar um coletor de estatísticas para cada modelo de controle de semáforos.
2. Registrar os eventos relevantes durante a simulação (início/fim de viagens, paradas em semáforos, etc.).
3. Ao final da simulação, gerar os relatórios desejados.

## Exemplo de Uso

Veja a classe `EstatisticasDemo.java` para um exemplo completo de como usar o sistema de estatísticas.

```java
public static void main(String[] args) {
    // Cria coletores de estatísticas
    EstatisticasColetor coletorCicloFixo = new EstatisticasColetorImpl("Ciclo Fixo");
    coletorCicloFixo.inicializar();
    
    // Registra eventos durante a simulação
    // ...
    
    // Gera relatórios
    System.out.println(coletorCicloFixo.gerarRelatorio());
}
```

## Extensão do Sistema

O sistema de estatísticas foi projetado para ser facilmente extensível. Para adicionar novas métricas ou tipos de relatórios:

1. Adicione novos métodos na interface `EstatisticasColetor` e sua implementação.
2. Atualize a classe `RelatorioGerador` para incluir as novas métricas nos relatórios.
3. Se necessário, adicione novos tipos de gráficos na classe `GraficoASCII`.
