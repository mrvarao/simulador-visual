
package com.simulador.estatisticas;

import java.util.List;
import java.util.Map;

/**
 * Classe responsável por gerar relatórios a partir das estatísticas coletadas.
 */
public class RelatorioGerador {
    
    /**
     * Gera um relatório detalhado com as estatísticas coletadas.
     * 
     * @param coletor Coletor de estatísticas
     * @return Relatório formatado
     */
    public String gerarRelatorio(EstatisticasColetorImpl coletor) {
        StringBuilder sb = new StringBuilder();
        
        // Cabeçalho do relatório
        sb.append("=".repeat(80)).append("\n");
        sb.append(" RELATÓRIO DE ESTATÍSTICAS - SIMULADOR DE MOBILIDADE URBANA\n");
        sb.append(" Modelo de Controle: ").append(coletor.getModeloControle()).append("\n");
        sb.append("=".repeat(80)).append("\n\n");
        
        // Estatísticas gerais
        Map<String, Object> estatisticas = coletor.getEstatisticas();
        sb.append("ESTATÍSTICAS GERAIS\n");
        sb.append("-".repeat(80)).append("\n");
        sb.append(String.format("Tempo Total de Simulação: %d segundos\n", coletor.getTempoTotalSimulacao()));
        sb.append(String.format("Total de Viagens Completas: %d\n", estatisticas.get("total_viagens_completas")));
        sb.append(String.format("Total de Viagens Ativas: %d\n", estatisticas.get("total_viagens_ativas")));
        sb.append(String.format("Tempo Médio de Viagem: %.2f segundos\n", estatisticas.get("tempo_medio_viagem")));
        sb.append(String.format("Tempo Médio de Espera em Semáforos: %.2f segundos\n", estatisticas.get("tempo_medio_espera_semaforos")));
        sb.append(String.format("Percentual de Tempo em Espera: %.2f%%\n", estatisticas.get("percentual_tempo_espera")));
        sb.append(String.format("Consumo Energético Total: %.2f unidades\n", estatisticas.get("consumo_energetico_total")));
        sb.append(String.format("Consumo Energético Médio por Semáforo: %.2f unidades\n", estatisticas.get("consumo_energetico_medio")));
        sb.append(String.format("Nível Médio de Congestionamento: %.2f%%\n", estatisticas.get("nivel_medio_congestionamento")));
        sb.append(String.format("Fluxo Total de Veículos: %d\n", estatisticas.get("fluxo_total_veiculos")));
        sb.append("\n");
        
        // Gráfico de tempo médio de viagem
        sb.append("TEMPO MÉDIO DE VIAGEM\n");
        sb.append("-".repeat(80)).append("\n");
        double tempoMedioViagem = (double) estatisticas.get("tempo_medio_viagem");
        sb.append(gerarGraficoBarraHorizontal("Tempo Total", tempoMedioViagem, 60));
        
        double tempoMedioEspera = (double) estatisticas.get("tempo_medio_espera_semaforos");
        sb.append(gerarGraficoBarraHorizontal("Tempo em Semáforos", tempoMedioEspera, 60));
        
        double tempoMedioMovimento = tempoMedioViagem - tempoMedioEspera;
        sb.append(gerarGraficoBarraHorizontal("Tempo em Movimento", tempoMedioMovimento, 60));
        sb.append("\n");
        
        // Gráfico de consumo energético
        sb.append("CONSUMO ENERGÉTICO POR SEMÁFORO\n");
        sb.append("-".repeat(80)).append("\n");
        Map<Integer, EstatisticasColetorImpl.SemaforoInfo> infoSemaforos = coletor.getInfoSemaforos();
        if (!infoSemaforos.isEmpty()) {
            for (Map.Entry<Integer, EstatisticasColetorImpl.SemaforoInfo> entry : infoSemaforos.entrySet()) {
                int idSemaforo = entry.getKey();
                double consumo = entry.getValue().getConsumoEnergeticoTotal();
                sb.append(gerarGraficoBarraHorizontal("Semáforo " + idSemaforo, consumo, 60));
            }
        } else {
            sb.append("Nenhum dado de consumo energético disponível.\n");
        }
        sb.append("\n");
        
        // Gráfico de congestionamento
        sb.append("NÍVEIS DE CONGESTIONAMENTO\n");
        sb.append("-".repeat(80)).append("\n");
        Map<String, List<EstatisticasColetorImpl.CongestionamentoInfo>> congestionamentos = coletor.getCongestionamentos();
        if (!congestionamentos.isEmpty()) {
            for (Map.Entry<String, List<EstatisticasColetorImpl.CongestionamentoInfo>> entry : congestionamentos.entrySet()) {
                String coordenadas = entry.getKey();
                double nivelMedio = entry.getValue().stream()
                        .mapToInt(EstatisticasColetorImpl.CongestionamentoInfo::getNivel)
                        .average()
                        .orElse(0.0);
                sb.append(gerarGraficoBarraHorizontal("Ponto " + coordenadas, nivelMedio, 60));
            }
        } else {
            sb.append("Nenhum dado de congestionamento disponível.\n");
        }
        sb.append("\n");
        
        // Gráfico de fluxo de veículos
        sb.append("FLUXO DE VEÍCULOS\n");
        sb.append("-".repeat(80)).append("\n");
        Map<String, List<EstatisticasColetorImpl.FluxoInfo>> fluxoVeiculos = coletor.getFluxoVeiculos();
        if (!fluxoVeiculos.isEmpty()) {
            for (Map.Entry<String, List<EstatisticasColetorImpl.FluxoInfo>> entry : fluxoVeiculos.entrySet()) {
                String coordenadas = entry.getKey();
                double fluxoMedio = entry.getValue().stream()
                        .mapToInt(EstatisticasColetorImpl.FluxoInfo::getFluxo)
                        .average()
                        .orElse(0.0);
                sb.append(gerarGraficoBarraHorizontal("Ponto " + coordenadas, fluxoMedio, 60));
            }
        } else {
            sb.append("Nenhum dado de fluxo de veículos disponível.\n");
        }
        sb.append("\n");
        
        // Rodapé do relatório
        sb.append("=".repeat(80)).append("\n");
        sb.append(" FIM DO RELATÓRIO\n");
        sb.append("=".repeat(80)).append("\n");
        
        return sb.toString();
    }
    
    /**
     * Gera um gráfico de barra horizontal em ASCII/Unicode.
     * 
     * @param rotulo Rótulo do gráfico
     * @param valor Valor a ser representado
     * @param tamanhoMaximo Tamanho máximo da barra
     * @return Gráfico formatado
     */
    private String gerarGraficoBarraHorizontal(String rotulo, double valor, int tamanhoMaximo) {
        StringBuilder sb = new StringBuilder();
        
        // Formata o rótulo para ocupar 20 caracteres
        String rotuloFormatado = String.format("%-20s", rotulo);
        
        // Calcula o tamanho da barra (proporcional ao valor)
        int tamanhoBarra = (int) Math.min(tamanhoMaximo, Math.round(valor));
        
        // Gera a barra
        sb.append(rotuloFormatado).append(" [");
        sb.append("█".repeat(tamanhoBarra));
        sb.append(" ".repeat(tamanhoMaximo - tamanhoBarra));
        sb.append("] ").append(String.format("%.2f", valor)).append("\n");
        
        return sb.toString();
    }
    
    /**
     * Gera um gráfico de linha em ASCII/Unicode.
     * 
     * @param titulo Título do gráfico
     * @param valores Lista de valores a serem representados
     * @param rotulos Lista de rótulos para o eixo X
     * @param altura Altura do gráfico
     * @param largura Largura do gráfico
     * @return Gráfico formatado
     */
    public String gerarGraficoLinha(String titulo, List<Double> valores, List<String> rotulos, int altura, int largura) {
        StringBuilder sb = new StringBuilder();
        
        // Título do gráfico
        sb.append(titulo).append("\n");
        sb.append("-".repeat(largura)).append("\n");
        
        // Encontra o valor máximo para escala
        double valorMaximo = valores.stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        
        // Gera o gráfico
        for (int y = altura - 1; y >= 0; y--) {
            double limiteAtual = valorMaximo * (y + 1) / altura;
            
            // Eixo Y
            sb.append(String.format("%6.1f |", limiteAtual));
            
            // Pontos do gráfico
            for (int x = 0; x < valores.size(); x++) {
                double valor = valores.get(x);
                double limiteSuperior = valorMaximo * (y + 1) / altura;
                double limiteInferior = valorMaximo * y / altura;
                
                if (valor >= limiteSuperior) {
                    sb.append("█");
                } else if (valor >= limiteInferior) {
                    sb.append("▓");
                } else {
                    sb.append(" ");
                }
            }
            
            sb.append("\n");
        }
        
        // Eixo X
        sb.append("       ");
        sb.append("-".repeat(valores.size())).append("\n");
        
        // Rótulos do eixo X
        sb.append("       ");
        for (int i = 0; i < rotulos.size(); i++) {
            if (i % 5 == 0) {
                sb.append("|");
            } else {
                sb.append(" ");
            }
        }
        sb.append("\n");
        
        return sb.toString();
    }
}
