
package com.simulador.principal;

import com.simulador.semaforos.SemaforoFactory;

import java.util.Scanner;

/**
 * Interface de linha de comando para configuração da simulação.
 * Versão simplificada para o simulador do bairro Morada do Sol.
 */
public class ConfigCLI {
    
    private Scanner scanner;
    
    /**
     * Construtor da interface de configuração.
     */
    public ConfigCLI() {
        scanner = new Scanner(System.in);
    }
    
    /**
     * Obtém as configurações da simulação a partir da interação com o usuário.
     * Versão simplificada com menos opções e valores predefinidos para o bairro Morada do Sol.
     * 
     * @return Configurações da simulação
     */
    public ConfiguracaoSimulacao obterConfiguracoes() {
        ConfiguracaoSimulacao config = new ConfiguracaoSimulacao();
        
        try {
            System.out.println("=".repeat(60));
            System.out.println("  SIMULADOR DE MOBILIDADE URBANA - BAIRRO MORADA DO SOL");
            System.out.println("=".repeat(60));
            System.out.println();
            
            // Configurações predefinidas para o bairro Morada do Sol
            config.setTamanhoCidade(new int[]{50, 25}); // Tamanho maior para o bairro
            config.setTipoControladorSemaforo(SemaforoFactory.TipoControlador.TEMPO_ESPERA); // Sempre usa o modelo de otimização do tempo de espera
            
            // Verifica se há entrada disponível
            if (System.in.available() == 0) {
                System.out.println("Modo não interativo detectado. Usando configurações padrão.");
                return config; // Retorna configuração padrão
            }
            
            // Configuração da duração da simulação
            System.out.println("DURAÇÃO DA SIMULAÇÃO");
            System.out.println("-".repeat(60));
            System.out.print("Duração em segundos (60-3600, padrão: 300): ");
            String input = scanner.nextLine().trim();
            int duracao = input.isEmpty() ? 300 : Integer.parseInt(input);
            config.setDuracaoSimulacao(duracao);
            System.out.println();
            
            // Configuração da velocidade da simulação
            System.out.println("VELOCIDADE DA SIMULAÇÃO");
            System.out.println("-".repeat(60));
            System.out.println("1. Lenta (500ms por ciclo)");
            System.out.println("2. Normal (200ms por ciclo)");
            System.out.println("3. Rápida (50ms por ciclo)");
            System.out.print("Escolha (1-3, padrão: 2): ");
            input = scanner.nextLine().trim();
            
            int velocidade;
            switch (input) {
                case "1":
                    velocidade = 500;
                    break;
                case "3":
                    velocidade = 50;
                    break;
                default:
                    velocidade = 200;
                    break;
            }
            
            config.setVelocidadeSimulacao(velocidade);
            System.out.println();
            
            // Configuração dos veículos
            System.out.println("CONFIGURAÇÃO DE VEÍCULOS");
            System.out.println("-".repeat(60));
            System.out.print("Número inicial de veículos (1-30, padrão: 10): ");
            input = scanner.nextLine().trim();
            int numInicial = input.isEmpty() ? 10 : Integer.parseInt(input);
            config.setNumeroInicialVeiculos(numInicial);
            
            System.out.print("Número máximo de veículos (10-100, padrão: 30): ");
            input = scanner.nextLine().trim();
            int numMaximo = input.isEmpty() ? 30 : Integer.parseInt(input);
            config.setNumeroMaximoVeiculos(numMaximo);
            
            System.out.print("Taxa de geração de novos veículos (0.0-1.0, padrão: 0.1): ");
            input = scanner.nextLine().trim();
            double taxa = input.isEmpty() ? 0.1 : Double.parseDouble(input);
            config.setTaxaGeracaoVeiculos(taxa);
            System.out.println();
            
            System.out.println("=".repeat(60));
            System.out.println("  CONFIGURAÇÃO CONCLUÍDA");
            System.out.println("=".repeat(60));
            System.out.println();
            System.out.println("Pressione ENTER para iniciar a simulação...");
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("Erro ou modo não interativo detectado. Usando configurações padrão.");
            System.out.println("Erro: " + e.getMessage());
        }
        
        return config;
    }
}
