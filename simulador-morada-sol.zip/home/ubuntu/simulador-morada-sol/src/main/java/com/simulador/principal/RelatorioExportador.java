
package com.simulador.principal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Classe responsável por exportar relatórios para arquivos.
 */
public class RelatorioExportador {
    
    // Diretório padrão para salvar os relatórios
    private static final String DIRETORIO_RELATORIOS = "relatorios";
    
    /**
     * Salva um relatório em um arquivo.
     * 
     * @param conteudo Conteúdo do relatório
     * @param nomeArquivo Nome do arquivo
     * @return Caminho do arquivo salvo
     */
    public static String salvarRelatorio(String conteudo, String nomeArquivo) {
        try {
            // Cria o diretório de relatórios se não existir
            Path diretorio = Paths.get(DIRETORIO_RELATORIOS);
            if (!Files.exists(diretorio)) {
                Files.createDirectories(diretorio);
            }
            
            // Caminho completo do arquivo
            String caminhoArquivo = DIRETORIO_RELATORIOS + "/" + nomeArquivo;
            
            // Escreve o conteúdo no arquivo
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(caminhoArquivo))) {
                writer.write(conteudo);
            }
            
            return caminhoArquivo;
        } catch (IOException e) {
            System.err.println("Erro ao salvar relatório: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Salva um relatório comparativo em um arquivo.
     * 
     * @param conteudo Conteúdo do relatório
     * @return Caminho do arquivo salvo
     */
    public static String salvarRelatorioComparativo(String conteudo) {
        return salvarRelatorio(conteudo, "relatorio_comparativo.txt");
    }
}
