
package com.simulador.principal;

import com.simulador.semaforos.SemaforoFactory;

/**
 * Classe que armazena as configurações da simulação.
 */
public class ConfiguracaoSimulacao {
    
    // Tamanho da cidade (largura, altura)
    private int[] tamanhoCidade;
    
    // Tipo de controlador de semáforos
    private SemaforoFactory.TipoControlador tipoControladorSemaforo;
    
    // Duração da simulação em segundos
    private int duracaoSimulacao;
    
    // Velocidade da simulação em milissegundos por ciclo
    private int velocidadeSimulacao;
    
    // Número inicial de veículos
    private int numeroInicialVeiculos;
    
    // Número máximo de veículos
    private int numeroMaximoVeiculos;
    
    // Taxa de geração de novos veículos (0.0 - 1.0)
    private double taxaGeracaoVeiculos;
    
    /**
     * Construtor com valores padrão.
     */
    public ConfiguracaoSimulacao() {
        // Valores padrão
        this.tamanhoCidade = new int[]{30, 15};
        this.tipoControladorSemaforo = SemaforoFactory.TipoControlador.TEMPO_ESPERA;
        this.duracaoSimulacao = 300; // 5 minutos
        this.velocidadeSimulacao = 200; // 200ms por ciclo
        this.numeroInicialVeiculos = 5;
        this.numeroMaximoVeiculos = 20;
        this.taxaGeracaoVeiculos = 0.05;
    }
    
    /**
     * Construtor com parâmetros.
     * 
     * @param tamanhoCidade Tamanho da cidade (largura, altura)
     * @param tipoControladorSemaforo Tipo de controlador de semáforos
     * @param duracaoSimulacao Duração da simulação em segundos
     * @param velocidadeSimulacao Velocidade da simulação em milissegundos por ciclo
     * @param numeroInicialVeiculos Número inicial de veículos
     * @param numeroMaximoVeiculos Número máximo de veículos
     * @param taxaGeracaoVeiculos Taxa de geração de novos veículos (0.0 - 1.0)
     */
    public ConfiguracaoSimulacao(int[] tamanhoCidade, SemaforoFactory.TipoControlador tipoControladorSemaforo,
                                int duracaoSimulacao, int velocidadeSimulacao, int numeroInicialVeiculos,
                                int numeroMaximoVeiculos, double taxaGeracaoVeiculos) {
        this.tamanhoCidade = tamanhoCidade;
        this.tipoControladorSemaforo = tipoControladorSemaforo;
        this.duracaoSimulacao = duracaoSimulacao;
        this.velocidadeSimulacao = velocidadeSimulacao;
        this.numeroInicialVeiculos = numeroInicialVeiculos;
        this.numeroMaximoVeiculos = numeroMaximoVeiculos;
        this.taxaGeracaoVeiculos = taxaGeracaoVeiculos;
    }
    
    // Getters e Setters
    
    public int[] getTamanhoCidade() {
        return tamanhoCidade;
    }
    
    public void setTamanhoCidade(int[] tamanhoCidade) {
        this.tamanhoCidade = tamanhoCidade;
    }
    
    public SemaforoFactory.TipoControlador getTipoControladorSemaforo() {
        return tipoControladorSemaforo;
    }
    
    public void setTipoControladorSemaforo(SemaforoFactory.TipoControlador tipoControladorSemaforo) {
        this.tipoControladorSemaforo = tipoControladorSemaforo;
    }
    
    public int getDuracaoSimulacao() {
        return duracaoSimulacao;
    }
    
    public void setDuracaoSimulacao(int duracaoSimulacao) {
        this.duracaoSimulacao = duracaoSimulacao;
    }
    
    public int getVelocidadeSimulacao() {
        return velocidadeSimulacao;
    }
    
    public void setVelocidadeSimulacao(int velocidadeSimulacao) {
        this.velocidadeSimulacao = velocidadeSimulacao;
    }
    
    public int getNumeroInicialVeiculos() {
        return numeroInicialVeiculos;
    }
    
    public void setNumeroInicialVeiculos(int numeroInicialVeiculos) {
        this.numeroInicialVeiculos = numeroInicialVeiculos;
    }
    
    public int getNumeroMaximoVeiculos() {
        return numeroMaximoVeiculos;
    }
    
    public void setNumeroMaximoVeiculos(int numeroMaximoVeiculos) {
        this.numeroMaximoVeiculos = numeroMaximoVeiculos;
    }
    
    public double getTaxaGeracaoVeiculos() {
        return taxaGeracaoVeiculos;
    }
    
    public void setTaxaGeracaoVeiculos(double taxaGeracaoVeiculos) {
        this.taxaGeracaoVeiculos = taxaGeracaoVeiculos;
    }
}
