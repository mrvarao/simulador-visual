
package com.simulador.estruturas;

/**
 * Implementação de uma pilha (LIFO - Last In, First Out) para operações de busca e rastreamento.
 * Esta estrutura é útil para armazenar caminhos, histórico de operações, etc.
 * 
 * @param <T> Tipo de dados armazenados na pilha
 */
public class Pilha<T> {
    
    /**
     * Classe interna que representa um nó na pilha
     */
    private class No {
        private T dado;
        private No proximo;
        
        /**
         * Construtor do nó
         * 
         * @param dado Dado a ser armazenado no nó
         */
        public No(T dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }
    
    private No topo;
    private int tamanho;
    
    /**
     * Construtor da pilha
     */
    public Pilha() {
        this.topo = null;
        this.tamanho = 0;
    }
    
    /**
     * Verifica se a pilha está vazia
     * 
     * @return true se a pilha estiver vazia, false caso contrário
     */
    public boolean estaVazia() {
        return tamanho == 0;
    }
    
    /**
     * Retorna o tamanho atual da pilha
     * 
     * @return Número de elementos na pilha
     */
    public int tamanho() {
        return tamanho;
    }
    
    /**
     * Adiciona um elemento ao topo da pilha (empilhar)
     * 
     * @param dado Elemento a ser adicionado
     */
    public void empilhar(T dado) {
        No novoNo = new No(dado);
        novoNo.proximo = topo;
        topo = novoNo;
        tamanho++;
    }
    
    /**
     * Remove e retorna o elemento do topo da pilha (desempilhar)
     * 
     * @return O elemento removido do topo da pilha
     * @throws IllegalStateException Se a pilha estiver vazia
     */
    public T desempilhar() {
        if (estaVazia()) {
            throw new IllegalStateException("A pilha está vazia");
        }
        
        T dado = topo.dado;
        topo = topo.proximo;
        tamanho--;
        
        return dado;
    }
    
    /**
     * Retorna o elemento do topo da pilha sem removê-lo
     * 
     * @return O elemento do topo da pilha
     * @throws IllegalStateException Se a pilha estiver vazia
     */
    public T topo() {
        if (estaVazia()) {
            throw new IllegalStateException("A pilha está vazia");
        }
        
        return topo.dado;
    }
    
    /**
     * Limpa a pilha, removendo todos os elementos
     */
    public void limpar() {
        topo = null;
        tamanho = 0;
    }
    
    /**
     * Verifica se um elemento está presente na pilha
     * 
     * @param dado Elemento a ser verificado
     * @return true se o elemento estiver na pilha, false caso contrário
     */
    public boolean contem(T dado) {
        No atual = topo;
        
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                return true;
            }
            atual = atual.proximo;
        }
        
        return false;
    }
}
