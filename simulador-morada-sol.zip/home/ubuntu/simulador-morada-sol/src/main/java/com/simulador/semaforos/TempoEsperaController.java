
package com.simulador.semaforos;

import com.simulador.visualizacao.TrafficLightSymbol;
import java.util.HashMap;
import java.util.Map;

/**
 * Implementação do modelo de controle de semáforos com otimização do tempo de espera.
 * Este modelo ajusta dinamicamente os tempos dos semáforos com base no fluxo de veículos,
 * priorizando as vias com maior tráfego para minimizar o tempo médio de espera.
 */
public class TempoEsperaController implements SemaforoController {
    
    // Tempos mínimos e máximos para cada fase (em segundos)
    private static final int TEMPO_VERDE_MIN = 15;
    private static final int TEMPO_VERDE_MAX = 60;
    private static final int TEMPO_AMARELO = 5;
    private static final int TEMPO_VERMELHO_MIN = 20;
    
    // Fator de ajuste baseado no fluxo de veículos
    private static final double FATOR_AJUSTE = 0.5;
    
    // Mapa que armazena o estado atual de cada semáforo
    private Map<Integer, TrafficLightSymbol.State> estadoSemaforos;
    
    // Mapa que armazena o tempo restante para a próxima mudança de estado
    private Map<Integer, Integer> tempoRestante;
    
    // Mapa que armazena o fluxo médio de veículos por semáforo
    private Map<Integer, Double> fluxoMedio;
    
    // Mapa que armazena o tempo total de espera por semáforo
    private Map<Integer, Integer> tempoTotalEspera;
    
    // Estatísticas do controlador
    private Map<String, String> estatisticas;
    
    // Contador de ciclos completos
    private int ciclosCompletos;
    
    // Tempo médio de espera global
    private double tempoMedioEspera;
    
    /**
     * Construtor do controlador de otimização do tempo de espera.
     */
    public TempoEsperaController() {
        estadoSemaforos = new HashMap<>();
        tempoRestante = new HashMap<>();
        fluxoMedio = new HashMap<>();
        tempoTotalEspera = new HashMap<>();
        estatisticas = new HashMap<>();
        ciclosCompletos = 0;
        tempoMedioEspera = 0.0;
    }
    
    @Override
    public void inicializar() {
        // Inicializa as estatísticas
        estatisticas.put("Modelo", "Otimização do Tempo de Espera");
        estatisticas.put("Ciclos Completos", "0");
        estatisticas.put("Tempo Médio de Espera", "0.0s");
        estatisticas.put("Fluxo Médio Total", "0 veículos/min");
    }
    
    @Override
    public void atualizar(int tempoSimulacao, Map<Integer, Integer> fluxoVeiculos) {
        // Atualiza o fluxo médio para cada semáforo
        atualizarFluxoMedio(fluxoVeiculos);
        
        // Para cada semáforo no mapa de fluxo
        for (Integer idSemaforo : fluxoVeiculos.keySet()) {
            // Se o semáforo não estiver no mapa de estados, inicializa-o
            if (!estadoSemaforos.containsKey(idSemaforo)) {
                // Inicializa com estado verde e tempo calculado com base no fluxo
                estadoSemaforos.put(idSemaforo, TrafficLightSymbol.State.GREEN);
                int tempoVerde = calcularTempoVerde(idSemaforo, fluxoVeiculos.get(idSemaforo));
                tempoRestante.put(idSemaforo, tempoVerde);
                tempoTotalEspera.put(idSemaforo, 0);
            } else {
                // Decrementa o tempo restante
                int tempo = tempoRestante.get(idSemaforo) - 1;
                
                // Se o tempo acabou, muda o estado
                if (tempo <= 0) {
                    TrafficLightSymbol.State estadoAtual = estadoSemaforos.get(idSemaforo);
                    
                    switch (estadoAtual) {
                        case GREEN:
                            estadoSemaforos.put(idSemaforo, TrafficLightSymbol.State.YELLOW);
                            tempo = TEMPO_AMARELO;
                            break;
                        case YELLOW:
                            estadoSemaforos.put(idSemaforo, TrafficLightSymbol.State.RED);
                            // Calcula o tempo vermelho com base no fluxo das outras vias
                            tempo = calcularTempoVermelho(idSemaforo, fluxoVeiculos);
                            break;
                        case RED:
                            estadoSemaforos.put(idSemaforo, TrafficLightSymbol.State.GREEN);
                            // Recalcula o tempo verde com base no fluxo atual
                            tempo = calcularTempoVerde(idSemaforo, fluxoVeiculos.get(idSemaforo));
                            ciclosCompletos++;
                            estatisticas.put("Ciclos Completos", String.valueOf(ciclosCompletos));
                            break;
                    }
                }
                
                // Atualiza o tempo restante
                tempoRestante.put(idSemaforo, tempo);
                
                // Atualiza o tempo total de espera para semáforos vermelhos
                if (estadoSemaforos.get(idSemaforo) == TrafficLightSymbol.State.RED) {
                    int espera = tempoTotalEspera.get(idSemaforo) + fluxoVeiculos.get(idSemaforo);
                    tempoTotalEspera.put(idSemaforo, espera);
                }
            }
        }
        
        // Atualiza as estatísticas
        atualizarEstatisticas(fluxoVeiculos);
    }
    
    /**
     * Calcula o tempo ideal para a fase verde com base no fluxo de veículos.
     * 
     * @param idSemaforo ID do semáforo
     * @param fluxo Fluxo atual de veículos
     * @return Tempo calculado para a fase verde
     */
    private int calcularTempoVerde(int idSemaforo, int fluxo) {
        // Calcula o tempo verde proporcional ao fluxo, dentro dos limites
        double fluxoRelativo = fluxo / (fluxoMedio.getOrDefault(idSemaforo, 1.0) + 1.0);
        int tempoCalculado = (int) (TEMPO_VERDE_MIN + fluxoRelativo * FATOR_AJUSTE * (TEMPO_VERDE_MAX - TEMPO_VERDE_MIN));
        
        // Garante que o tempo está dentro dos limites
        return Math.max(TEMPO_VERDE_MIN, Math.min(tempoCalculado, TEMPO_VERDE_MAX));
    }
    
    /**
     * Calcula o tempo ideal para a fase vermelha com base no fluxo das outras vias.
     * 
     * @param idSemaforo ID do semáforo
     * @param fluxoVeiculos Mapa de fluxo de veículos
     * @return Tempo calculado para a fase vermelha
     */
    private int calcularTempoVermelho(int idSemaforo, Map<Integer, Integer> fluxoVeiculos) {
        // Calcula o fluxo total das outras vias
        int fluxoOutrasVias = 0;
        int contadorVias = 0;
        
        for (Map.Entry<Integer, Integer> entry : fluxoVeiculos.entrySet()) {
            if (!entry.getKey().equals(idSemaforo)) {
                fluxoOutrasVias += entry.getValue();
                contadorVias++;
            }
        }
        
        // Se não houver outras vias, usa o tempo mínimo
        if (contadorVias == 0) {
            return TEMPO_VERMELHO_MIN;
        }
        
        // Calcula o tempo vermelho proporcional ao fluxo das outras vias
        double fluxoMedioOutrasVias = fluxoOutrasVias / (double) contadorVias;
        int tempoCalculado = (int) (TEMPO_VERMELHO_MIN + fluxoMedioOutrasVias * FATOR_AJUSTE);
        
        // Garante que o tempo não é menor que o mínimo
        return Math.max(TEMPO_VERMELHO_MIN, tempoCalculado);
    }
    
    /**
     * Atualiza o fluxo médio de veículos para cada semáforo.
     * 
     * @param fluxoVeiculos Mapa de fluxo atual de veículos
     */
    private void atualizarFluxoMedio(Map<Integer, Integer> fluxoVeiculos) {
        for (Map.Entry<Integer, Integer> entry : fluxoVeiculos.entrySet()) {
            int idSemaforo = entry.getKey();
            int fluxoAtual = entry.getValue();
            
            // Se o semáforo já tem um fluxo médio, atualiza com média móvel
            if (fluxoMedio.containsKey(idSemaforo)) {
                double media = fluxoMedio.get(idSemaforo);
                // Média móvel com peso 0.8 para o valor antigo e 0.2 para o novo
                media = 0.8 * media + 0.2 * fluxoAtual;
                fluxoMedio.put(idSemaforo, media);
            } else {
                // Inicializa o fluxo médio com o valor atual
                fluxoMedio.put(idSemaforo, (double) fluxoAtual);
            }
        }
    }
    
    /**
     * Atualiza as estatísticas do controlador.
     * 
     * @param fluxoVeiculos Mapa de fluxo atual de veículos
     */
    private void atualizarEstatisticas(Map<Integer, Integer> fluxoVeiculos) {
        // Calcula o tempo médio de espera
        int totalEspera = 0;
        int totalVeiculos = 0;
        
        for (Map.Entry<Integer, Integer> entry : tempoTotalEspera.entrySet()) {
            totalEspera += entry.getValue();
        }
        
        for (Map.Entry<Integer, Integer> entry : fluxoVeiculos.entrySet()) {
            totalVeiculos += entry.getValue();
        }
        
        if (totalVeiculos > 0) {
            tempoMedioEspera = totalEspera / (double) totalVeiculos;
        }
        
        // Calcula o fluxo médio total
        double fluxoTotal = 0;
        for (Double fluxo : fluxoMedio.values()) {
            fluxoTotal += fluxo;
        }
        
        // Atualiza as estatísticas
        estatisticas.put("Tempo Médio de Espera", String.format("%.2f", tempoMedioEspera) + "s");
        estatisticas.put("Fluxo Médio Total", String.format("%.0f", fluxoTotal) + " veículos/min");
    }
    
    @Override
    public TrafficLightSymbol.State getEstadoSemaforo(int idSemaforo) {
        return estadoSemaforos.getOrDefault(idSemaforo, TrafficLightSymbol.State.RED);
    }
    
    @Override
    public int getTempoRestante(int idSemaforo) {
        return tempoRestante.getOrDefault(idSemaforo, 0);
    }
    
    @Override
    public Map<String, String> getEstatisticas() {
        return estatisticas;
    }
    
    @Override
    public String getNomeModelo() {
        return "Otimização do Tempo de Espera";
    }
}
