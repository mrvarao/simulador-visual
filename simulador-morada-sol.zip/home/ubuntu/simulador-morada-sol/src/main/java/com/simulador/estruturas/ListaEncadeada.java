
package com.simulador.estruturas;

/**
 * Implementação de uma lista encadeada simples para armazenar elementos em sequência.
 * Esta estrutura permite adicionar, remover e acessar elementos em diferentes posições.
 * 
 * @param <T> Tipo de dados armazenados na lista
 */
public class ListaEncadeada<T> {
    
    /**
     * Classe interna que representa um nó na lista encadeada
     */
    private class No {
        private T dado;
        private No proximo;
        
        /**
         * Construtor do nó
         * 
         * @param dado Dado a ser armazenado no nó
         */
        public No(T dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }
    
    private No primeiro;
    private No ultimo;
    private int tamanho;
    
    /**
     * Construtor da lista encadeada
     */
    public ListaEncadeada() {
        this.primeiro = null;
        this.ultimo = null;
        this.tamanho = 0;
    }
    
    /**
     * Verifica se a lista está vazia
     * 
     * @return true se a lista estiver vazia, false caso contrário
     */
    public boolean estaVazia() {
        return tamanho == 0;
    }
    
    /**
     * Retorna o tamanho atual da lista
     * 
     * @return Número de elementos na lista
     */
    public int tamanho() {
        return tamanho;
    }
    
    /**
     * Adiciona um elemento ao final da lista
     * 
     * @param dado Elemento a ser adicionado
     */
    public void adicionar(T dado) {
        No novoNo = new No(dado);
        
        if (estaVazia()) {
            primeiro = novoNo;
            ultimo = novoNo;
        } else {
            ultimo.proximo = novoNo;
            ultimo = novoNo;
        }
        
        tamanho++;
    }
    
    /**
     * Adiciona um elemento em uma posição específica da lista
     * 
     * @param dado Elemento a ser adicionado
     * @param indice Posição onde o elemento será adicionado
     * @throws IndexOutOfBoundsException Se o índice for inválido
     */
    public void adicionar(T dado, int indice) {
        if (indice < 0 || indice > tamanho) {
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
        }
        
        if (indice == tamanho) {
            adicionar(dado);
            return;
        }
        
        No novoNo = new No(dado);
        
        if (indice == 0) {
            novoNo.proximo = primeiro;
            primeiro = novoNo;
        } else {
            No anterior = buscarNo(indice - 1);
            novoNo.proximo = anterior.proximo;
            anterior.proximo = novoNo;
        }
        
        tamanho++;
    }
    
    /**
     * Remove o elemento em uma posição específica da lista
     * 
     * @param indice Posição do elemento a ser removido
     * @return O elemento removido
     * @throws IndexOutOfBoundsException Se o índice for inválido
     */
    public T remover(int indice) {
        if (estaVazia() || indice < 0 || indice >= tamanho) {
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
        }
        
        No removido;
        
        if (indice == 0) {
            removido = primeiro;
            primeiro = primeiro.proximo;
            
            if (tamanho == 1) {
                ultimo = null;
            }
        } else {
            No anterior = buscarNo(indice - 1);
            removido = anterior.proximo;
            anterior.proximo = removido.proximo;
            
            if (indice == tamanho - 1) {
                ultimo = anterior;
            }
        }
        
        tamanho--;
        return removido.dado;
    }
    
    /**
     * Obtém o elemento em uma posição específica da lista
     * 
     * @param indice Posição do elemento a ser obtido
     * @return O elemento na posição especificada
     * @throws IndexOutOfBoundsException Se o índice for inválido
     */
    public T obter(int indice) {
        if (estaVazia() || indice < 0 || indice >= tamanho) {
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
        }
        
        return buscarNo(indice).dado;
    }
    
    /**
     * Busca um nó em uma posição específica da lista
     * 
     * @param indice Posição do nó a ser buscado
     * @return O nó na posição especificada
     */
    private No buscarNo(int indice) {
        No atual = primeiro;
        
        for (int i = 0; i < indice; i++) {
            atual = atual.proximo;
        }
        
        return atual;
    }
    
    /**
     * Limpa a lista, removendo todos os elementos
     */
    public void limpar() {
        primeiro = null;
        ultimo = null;
        tamanho = 0;
    }
    
    /**
     * Verifica se um elemento está presente na lista
     * 
     * @param dado Elemento a ser verificado
     * @return true se o elemento estiver na lista, false caso contrário
     */
    public boolean contem(T dado) {
        No atual = primeiro;
        
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                return true;
            }
            atual = atual.proximo;
        }
        
        return false;
    }
}
