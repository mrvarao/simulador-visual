
package com.simulador.estruturas;

/**
 * Implementação de um grafo para representar a malha urbana no simulador de mobilidade.
 * Nesta estrutura, os vértices representam interseções/pontos de interesse na cidade,
 * enquanto as arestas representam as ruas/conexões entre esses pontos.
 * 
 * Esta implementação utiliza lista de adjacência para representar o grafo.
 */
public class Grafo {
    
    /**
     * Classe interna que representa um vértice no grafo
     */
    private class Vertice {
        private int id;
        private String nome;
        private ListaEncadeada<Aresta> arestas;
        
        /**
         * Construtor do vértice
         * 
         * @param id Identificador único do vértice
         * @param nome Nome descritivo do vértice (ex: nome da interseção)
         */
        public Vertice(int id, String nome) {
            this.id = id;
            this.nome = nome;
            this.arestas = new ListaEncadeada<>();
        }
        
        /**
         * Adiciona uma aresta conectando este vértice a outro
         * 
         * @param destino Vértice de destino
         * @param peso Peso da aresta (ex: distância, tempo de viagem)
         * @param nome Nome da rua/conexão
         * @return A aresta criada
         */
        public Aresta adicionarAresta(Vertice destino, double peso, String nome) {
            Aresta aresta = new Aresta(this, destino, peso, nome);
            arestas.adicionar(aresta);
            return aresta;
        }
    }
    
    /**
     * Classe interna que representa uma aresta no grafo
     */
    private class Aresta {
        private Vertice origem;
        private Vertice destino;
        private double peso;
        private String nome;
        
        /**
         * Construtor da aresta
         * 
         * @param origem Vértice de origem
         * @param destino Vértice de destino
         * @param peso Peso da aresta (ex: distância, tempo de viagem)
         * @param nome Nome da rua/conexão
         */
        public Aresta(Vertice origem, Vertice destino, double peso, String nome) {
            this.origem = origem;
            this.destino = destino;
            this.peso = peso;
            this.nome = nome;
        }
    }
    
    private ListaEncadeada<Vertice> vertices;
    
    /**
     * Construtor do grafo
     */
    public Grafo() {
        this.vertices = new ListaEncadeada<>();
    }
    
    /**
     * Adiciona um novo vértice ao grafo
     * 
     * @param id Identificador único do vértice
     * @param nome Nome descritivo do vértice
     * @return O vértice criado
     */
    public Vertice adicionarVertice(int id, String nome) {
        Vertice novoVertice = new Vertice(id, nome);
        vertices.adicionar(novoVertice);
        return novoVertice;
    }
    
    /**
     * Busca um vértice pelo seu ID
     * 
     * @param id ID do vértice a ser buscado
     * @return O vértice encontrado ou null se não existir
     */
    public Vertice buscarVertice(int id) {
        for (int i = 0; i < vertices.tamanho(); i++) {
            Vertice v = vertices.obter(i);
            if (v.id == id) {
                return v;
            }
        }
        return null;
    }
    
    /**
     * Adiciona uma aresta entre dois vértices do grafo
     * 
     * @param idOrigem ID do vértice de origem
     * @param idDestino ID do vértice de destino
     * @param peso Peso da aresta
     * @param nome Nome da rua/conexão
     * @return true se a aresta foi adicionada com sucesso, false caso contrário
     */
    public boolean adicionarAresta(int idOrigem, int idDestino, double peso, String nome) {
        Vertice origem = buscarVertice(idOrigem);
        Vertice destino = buscarVertice(idDestino);
        
        if (origem == null || destino == null) {
            return false;
        }
        
        origem.adicionarAresta(destino, peso, nome);
        return true;
    }
    
    /**
     * Retorna o número de vértices no grafo
     * 
     * @return Número de vértices
     */
    public int numeroDeVertices() {
        return vertices.tamanho();
    }
    
    /**
     * Implementa o algoritmo de Dijkstra para encontrar o caminho mais curto entre dois vértices
     * 
     * @param idOrigem ID do vértice de origem
     * @param idDestino ID do vértice de destino
     * @return Uma pilha contendo os IDs dos vértices no caminho, do destino à origem
     */
    public Pilha<Integer> encontrarCaminhoMaisCurto(int idOrigem, int idDestino) {
        // Implementação do algoritmo de Dijkstra seria feita aqui
        // Por simplicidade, retornamos uma pilha vazia por enquanto
        return new Pilha<>();
    }
}
