
package com.simulador.visualizacao;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe responsável por renderizar o mapa da cidade usando caracteres Unicode.
 * Representa ruas, cruzamentos, veículos e semáforos.
 */
public class CityMapCanvas {
    // Caracteres Unicode para desenho do mapa
    public static final char EMPTY = ' ';
    public static final char HORIZONTAL_ROAD = '━';  // U+2501
    public static final char VERTICAL_ROAD = '┃';    // U+2503
    public static final char CROSSROAD = '╋';        // U+254B
    public static final char TOP_LEFT_CORNER = '┏';  // U+250F
    public static final char TOP_RIGHT_CORNER = '┓'; // U+2513
    public static final char BOTTOM_LEFT_CORNER = '┗'; // U+2517
    public static final char BOTTOM_RIGHT_CORNER = '┛'; // U+251B
    public static final char T_UP = '┻';             // U+253B
    public static final char T_DOWN = '┳';           // U+2533
    public static final char T_LEFT = '┫';           // U+252B
    public static final char T_RIGHT = '┣';          // U+2523
    
    private int width;
    private int height;
    private char[][] mapGrid;
    private Map<String, VehicleSymbol> vehicles;
    private Map<String, TrafficLightSymbol> trafficLights;
    
    /**
     * Construtor do canvas do mapa da cidade
     * 
     * @param width Largura do mapa
     * @param height Altura do mapa
     */
    public CityMapCanvas(int width, int height) {
        this.width = width;
        this.height = height;
        this.mapGrid = new char[height][width];
        this.vehicles = new HashMap<>();
        this.trafficLights = new HashMap<>();
        
        // Inicializa o mapa com espaços vazios
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                mapGrid[y][x] = EMPTY;
            }
        }
    }
    
    /**
     * Define o tipo de célula em uma posição específica do mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param cellType Tipo de célula
     */
    public void setCell(int x, int y, char cellType) {
        if (isValidPosition(x, y)) {
            mapGrid[y][x] = cellType;
        }
    }
    
    /**
     * Obtém o tipo de célula em uma posição específica do mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @return O tipo de célula
     */
    public char getCell(int x, int y) {
        if (isValidPosition(x, y)) {
            return mapGrid[y][x];
        }
        return EMPTY;
    }
    
    /**
     * Verifica se uma posição é válida no mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @return true se a posição for válida, false caso contrário
     */
    private boolean isValidPosition(int x, int y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }
    
    /**
     * Adiciona um veículo ao mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param vehicle Símbolo do veículo
     */
    public void addVehicle(int x, int y, VehicleSymbol vehicle) {
        if (isValidPosition(x, y)) {
            String key = x + "," + y;
            vehicles.put(key, vehicle);
        }
    }
    
    /**
     * Remove um veículo do mapa
     * 
     * @param x Posição x
     * @param y Posição y
     */
    public void removeVehicle(int x, int y) {
        if (isValidPosition(x, y)) {
            String key = x + "," + y;
            vehicles.remove(key);
        }
    }
    
    /**
     * Adiciona um semáforo ao mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param trafficLight Símbolo do semáforo
     */
    public void addTrafficLight(int x, int y, TrafficLightSymbol trafficLight) {
        if (isValidPosition(x, y)) {
            String key = x + "," + y;
            trafficLights.put(key, trafficLight);
        }
    }
    
    /**
     * Atualiza o estado de um semáforo no mapa
     * 
     * @param x Posição x
     * @param y Posição y
     * @param state Novo estado do semáforo
     */
    public void updateTrafficLight(int x, int y, TrafficLightSymbol.State state) {
        if (isValidPosition(x, y)) {
            String key = x + "," + y;
            TrafficLightSymbol trafficLight = trafficLights.get(key);
            if (trafficLight != null) {
                trafficLight.setState(state);
            }
        }
    }
    
    /**
     * Renderiza o mapa da cidade
     * 
     * @return String contendo a representação do mapa
     */
    public String render() {
        StringBuilder sb = new StringBuilder();
        
        // Desenha a borda superior
        sb.append("┌");
        for (int x = 0; x < width; x++) {
            sb.append("─");
        }
        sb.append("┐\n");
        
        // Desenha o conteúdo do mapa
        for (int y = 0; y < height; y++) {
            sb.append("│");
            for (int x = 0; x < width; x++) {
                String key = x + "," + y;
                
                // Verifica se há um veículo nesta posição
                if (vehicles.containsKey(key)) {
                    VehicleSymbol vehicle = vehicles.get(key);
                    sb.append(vehicle.render());
                }
                // Verifica se há um semáforo nesta posição
                else if (trafficLights.containsKey(key)) {
                    TrafficLightSymbol trafficLight = trafficLights.get(key);
                    sb.append(trafficLight.render());
                }
                // Caso contrário, desenha a célula do mapa
                else {
                    sb.append(mapGrid[y][x]);
                }
            }
            sb.append("│\n");
        }
        
        // Desenha a borda inferior
        sb.append("└");
        for (int x = 0; x < width; x++) {
            sb.append("─");
        }
        sb.append("┘");
        
        return sb.toString();
    }
    
    /**
     * Obtém a largura do mapa
     * 
     * @return Largura do mapa
     */
    public int getWidth() {
        return width;
    }
    
    /**
     * Obtém a altura do mapa
     * 
     * @return Altura do mapa
     */
    public int getHeight() {
        return height;
    }
}
